# Legacy Modernization Skills for Claude Code

Four Claude Code skills for reverse-engineering and modernizing legacy applications, built to the [Agent Skills](https://agentskills.io) standard and the Claude Code skills spec.

| Command | What it does | Output |
|---------|--------------|--------|
| `/understand-legacy [module]` | Top-down reverse engineering: architecture, entry points, traced flows, risk | `LEGACY_NOTES.md` |
| `/generate-uml [module]` | Class / sequence / component / state / ER diagrams from real source | `docs/uml/*.mmd` |
| `/map-dependencies [module]` | Module, class, data & external deps; cycles; coupling; decomposition seams | `DEPENDENCY_MAP.md` |
| `/extract-business-rules [domain]` | Business rules → structured, traceable catalog with confidence levels | `BUSINESS_RULES.md` |

Each skill is model-invocable (Claude loads it automatically when relevant) and user-invocable (type the `/command`). Three of them run a bundled read-only survey script via dynamic context injection, so the skill arrives already grounded in your actual repo.

## Install

**Project-level** (this repo only) — commit the tree to version control:

```
.claude/skills/
├── understand-legacy/
├── generate-uml/
├── map-dependencies/
└── extract-business-rules/
```

Unzip the bundle at your repo root so the folders land under `.claude/skills/`. Claude Code picks them up automatically (live change detection; no restart needed if the `.claude/skills/` directory already existed).

**Personal-level** (all your projects) — copy each skill folder into `~/.claude/skills/` instead.

## Verify

```
claude
> What skills are available?
```

You should see the four commands. Try one:

```
> /understand-legacy
> /map-dependencies billing
```

## Notes

- The `!`…`` blocks in each SKILL.md are Claude Code dynamic context injection — the survey scripts run *before* Claude reads the skill, so their output is inlined. These run only in Claude Code (not claude.ai chat or the raw API).
- Scripts are read-only and safe; they only list files and grep for patterns.
- `allowed-tools` pre-approves just the specific commands each skill needs (the analyzers and its own script), so you aren't prompted mid-run. Review them before trusting the repo.
- Recommended sequence: `/understand-legacy` → `/generate-uml` → `/map-dependencies` → `/extract-business-rules`, then add characterization tests before modernizing in slices (strangler-fig).
