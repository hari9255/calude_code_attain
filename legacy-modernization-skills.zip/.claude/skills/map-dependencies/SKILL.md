---
name: map-dependencies
description: Map and analyze codebase dependencies (module, class, data, and external/third-party), find circular dependencies and coupling hotspots, and recommend safe decomposition seams. Outputs DEPENDENCY_MAP.md with a Mermaid graph.
when_to_use: Use when the user wants to map dependencies, find circular dependencies, analyze coupling, see what depends on what, find where to split a monolith, or audit library versions. Trigger phrases include "map dependencies", "find circular deps", "analyze coupling", "where can I split this", "audit our dependencies". Trigger for refactoring/modernization planning even without the word "dependency".
argument-hint: [module-or-package]
allowed-tools: Read Grep Glob Bash(mkdir *) Bash(npx madge *) Bash(npx depcheck *) Bash(pipdeptree *) Bash(pip-audit *) Bash(jdeps *) Bash(mvn dependency:tree *) Bash(dotnet list *) Bash(npm audit *) Bash(${CLAUDE_SKILL_DIR}/scripts/detect_stack.sh *)
---

# Map Dependencies

Reveal how a system is wired so it can be safely changed or decomposed. Good analysis finds the cycles, the hub components, and the natural seams where a monolith can be split with least pain.

## Detected stack and available analyzers

```!
bash ${CLAUDE_SKILL_DIR}/scripts/detect_stack.sh
```

Use the detection above to pick the right analyzer. Prefer running a real analyzer and interpreting its output over eyeballing imports.

## Analyze at multiple levels (report separately)

1. Module/package level — which packages depend on which. Best for decomposition seams.
2. Class/function level — fine-grained call/reference graph. Best for one area.
3. External/third-party — libraries and services, with versions.
4. Data dependencies — shared DB tables, files, caches, global/mutable state. Code-only tools miss these, and they're often hardest to break.

## Principles

- Separate internal from external — different problems, different fixes.
- Hunt for cycles — circular dependencies are prime refactoring targets; list each explicitly.
- Measure coupling — flag high fan-in (risky to change) and high fan-out (hard to isolate) components.
- Don't forget data coupling — two modules sharing a table are coupled with zero code references between them.
- Visualize — a graph exposes clusters and seams a list never will.

## Workflow

1. Read the stack detection above; choose level(s) based on the goal (decomposition → module; understand one area → class; upgrade → external). Scope to `$ARGUMENTS` if given.
2. Run the appropriate analyzer(s) and interpret the output.
3. Detect cycles; list each with participating units and a suggested break point.
4. Rank components by fan-in/fan-out; highlight hubs.
5. Catalog third-party libraries with versions; flag outdated/EOL; run a vulnerability check.
6. Map data dependencies (shared tables, files, singletons, globals).
7. Write `DEPENDENCY_MAP.md` using the template below, including a Mermaid graph.
8. Recommend decomposition seams based on cycles, coupling, and clusters.

## DEPENDENCY_MAP.md template

```markdown
# Dependency Analysis: [system]

## Internal dependency graph
[Mermaid graph]

## Circular dependencies
| Cycle | Units involved | Suggested break point |
|-------|----------------|-----------------------|

## Coupling hotspots
| Component | Fan-in | Fan-out | Risk note |
|-----------|--------|---------|-----------|

## External dependencies
| Library | Version | Status (current/outdated/EOL) | Vulnerabilities |
|---------|---------|-------------------------------|-----------------|

## Data dependencies
- Shared table/file/global: which modules touch it

## Recommended decomposition seams
- Proposed boundary, and why it's a clean cut
```

## Quality checklist

- Internal vs external clearly separated.
- Every cycle listed with a suggested break point.
- Fan-in/fan-out hubs identified.
- Data dependencies included, not just code.
- External versions and vulnerabilities checked.
- A visual graph produced, not just prose.

## Additional resources

- Per-language analyzer commands and interpretation tips: see [references/tooling.md](references/tooling.md).
