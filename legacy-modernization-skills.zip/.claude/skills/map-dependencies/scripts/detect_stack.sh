#!/usr/bin/env bash
# Detect project stack(s) and suggest the right dependency analyzer. Read-only.
set -euo pipefail

found=0
suggest() { echo "- $1"; found=1; }

echo "## Detected stack & suggested analyzers"

[ -f package.json ]   && suggest "Node/JS-TS  → npx madge --circular src/ ; npx depcheck ; npm audit"
{ [ -f requirements.txt ] || [ -f pyproject.toml ] || [ -f setup.cfg ]; } && \
                        suggest "Python      → pipdeptree ; pydeps <pkg> --show-cycles ; pip-audit"
{ ls *.csproj >/dev/null 2>&1 || [ -f global.json ]; } && \
                        suggest ".NET        → dotnet list package --outdated ; dotnet list package --vulnerable"
[ -f pom.xml ]        && suggest "Java (Maven)→ jdeps -verbose:class -recursive target/*.jar ; mvn dependency:tree"
{ [ -f build.gradle ] || [ -f build.gradle.kts ]; } && \
                        suggest "Java (Gradle)→ ./gradlew dependencies ; jdeps on built jar"
[ -f go.mod ]         && suggest "Go          → go mod graph ; go list -deps ./..."
[ -f Cargo.toml ]     && suggest "Rust        → cargo tree ; cargo audit"
[ -f composer.json ]  && suggest "PHP         → composer show --tree ; composer audit"
[ -f Gemfile ]        && suggest "Ruby        → bundle list ; bundler-audit"

if [ "$found" -eq 0 ]; then
  echo "- No standard manifest detected. Fall back to source-level import analysis."
fi

echo
echo "## Manifests present"
ls -1 package.json requirements.txt pyproject.toml pom.xml build.gradle build.gradle.kts \
      go.mod Cargo.toml composer.json Gemfile *.csproj 2>/dev/null || echo "(none)"
