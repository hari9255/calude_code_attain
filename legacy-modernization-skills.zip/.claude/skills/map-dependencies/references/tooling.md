# Dependency analyzers by stack

Prefer running a real analyzer and interpreting its output. Raw dumps aren't the deliverable — interpretation is.

## JavaScript / TypeScript
```bash
npx madge --circular src/            # list cycles
npx madge --image graph.svg src/     # visual graph
npx depcheck                         # unused / missing deps
npm audit                            # known vulnerabilities
```

## Python
```bash
pip install pydeps pipdeptree pip-audit
pipdeptree                           # dependency tree
pydeps yourpkg --show-cycles         # cycles + graph
pip-audit                            # vulnerabilities
```

## Java
```bash
jdeps -verbose:class -recursive target/app.jar   # class-level deps
mvn dependency:tree                              # library tree
mvn org.owasp:dependency-check-maven:check       # vulnerabilities
```

## .NET
```bash
dotnet list package --outdated
dotnet list package --vulnerable
```

## Go / Rust / PHP / Ruby
```bash
go mod graph            # Go
cargo tree ; cargo audit# Rust
composer show --tree    # PHP
bundle list             # Ruby
```

## Interpreting output
- A cycle A→B→A means neither can be extracted without the other. Break it by introducing an interface/port or moving shared types to a leaf module.
- High fan-in = many dependents. Changing it is high-blast-radius; stabilize its interface first.
- High fan-out = depends on many things. Hard to test in isolation; a candidate for dependency injection.
- Clusters with few edges crossing between them are natural service/module boundaries.

## Data dependencies (tools won't find these)
Grep for shared table names, global singletons, and static mutable state. Two modules that both write the same table are coupled even with no code edge between them — record these manually.
