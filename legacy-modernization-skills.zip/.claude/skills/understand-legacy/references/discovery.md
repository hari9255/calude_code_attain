# Discovery reference

Stack-specific hints for locating entry points and structure quickly. Use targeted search rather than reading whole trees.

## Entry-point patterns by stack

| Stack | Look for |
|-------|----------|
| Java / Spring | `public static void main`, `@RestController`, `@Controller`, `@RequestMapping`, `@Scheduled`, `@KafkaListener`, `web.xml` servlet mappings |
| .NET | `Main(`, `[ApiController]`, `Controller` classes, `Startup.cs` / `Program.cs`, `[HttpGet]`, Hangfire/Quartz jobs |
| Node / JS-TS | `app.get`/`router.*`, `express()`, `fastify`, `main` in package.json, `bin` scripts, cron libs |
| Python | `if __name__ == "__main__"`, Flask `@app.route`, Django `urls.py`, Celery `@task`, `console_scripts` in setup.cfg |
| PHP | front controller (`index.php`), route files, framework kernel (Laravel `routes/`, Symfony controllers) |
| Mainframe / COBOL | JCL job steps, `PROCEDURE DIVISION`, called programs (`CALL`), copybooks |
| Ruby | `config/routes.rb`, `rake` tasks, Sidekiq workers, `bin/` executables |

## Discovery commands (run via bash where available)

```bash
# Repo shape
git ls-files | sed 's|/[^/]*$||' | sort | uniq -c | sort -rn | head -40

# Build / dependency manifests
git ls-files | grep -Ei 'pom.xml|build.gradle|package.json|requirements|Gemfile|\.csproj|go.mod|Cargo.toml'

# Risk markers
grep -rniE 'TODO|FIXME|HACK|XXX|deprecated' --include='*.*' . | head -50

# Largest files (complexity hotspots)
git ls-files | xargs wc -l 2>/dev/null | sort -rn | head -20

# Find likely entry points (adjust pattern per stack)
grep -rniE 'def main|static void main|@RestController|@app.route|router\.(get|post)' . | head -50
```

## Anti-patterns to avoid
- Reading every file "to be thorough" — burns context and buries signal.
- Trusting comments over code — comments in legacy systems are frequently stale.
- Describing intended behavior instead of actual behavior — always ground claims in code.
