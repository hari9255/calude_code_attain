#!/usr/bin/env bash
# Quick, read-only survey of a codebase. Safe to run at repo root.
set -euo pipefail

echo "## Repo shape (top directories by file count)"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git ls-files 2>/dev/null | sed 's|/[^/]*$||' | sort | uniq -c | sort -rn | head -25
  FILES=$(git ls-files 2>/dev/null)
else
  find . -type f -not -path '*/.git/*' -not -path '*/node_modules/*' 2>/dev/null \
    | sed 's|/[^/]*$||' | sort | uniq -c | sort -rn | head -25
  FILES=$(find . -type f -not -path '*/.git/*' -not -path '*/node_modules/*' 2>/dev/null)
fi

echo
echo "## Build / dependency manifests"
echo "$FILES" | grep -Ei 'pom\.xml|build\.gradle|package\.json|requirements|Gemfile|\.csproj|go\.mod|Cargo\.toml|composer\.json|setup\.(py|cfg)|Makefile' | head -20 || echo "(none found)"

echo
echo "## Likely entry points"
grep -rniE 'def main|static void main|@RestController|@Controller|@RequestMapping|@app\.(route|get|post)|router\.(get|post|put|delete)|\[ApiController\]|if __name__ == .__main__.|@Scheduled|@KafkaListener|CALL ' \
  --include='*.java' --include='*.cs' --include='*.py' --include='*.js' --include='*.ts' \
  --include='*.rb' --include='*.php' --include='*.go' --include='*.cbl' . 2>/dev/null | head -40 || echo "(none matched)"

echo
echo "## Risk markers (TODO/FIXME/HACK/deprecated)"
grep -rniE 'TODO|FIXME|HACK|XXX|deprecated' . 2>/dev/null \
  --exclude-dir=.git --exclude-dir=node_modules | head -30 || echo "(none found)"

echo
echo "## Largest files (complexity hotspots)"
echo "$FILES" | xargs wc -l 2>/dev/null | sort -rn | sed -n '2,16p' || echo "(unable to size)"
