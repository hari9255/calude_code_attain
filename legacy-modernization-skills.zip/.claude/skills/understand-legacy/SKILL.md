---
name: understand-legacy
description: Reverse-engineer and understand a legacy or unfamiliar codebase top-down — architecture, entry points, execution flows, and risk areas — and record findings in LEGACY_NOTES.md.
when_to_use: Use when the user wants to understand, onboard onto, audit, reverse-engineer, or get the lay of the land of an existing/legacy/inherited application, or asks how a system works before modifying it. Trigger phrases include "understand this codebase", "how does this system work", "make sense of this legacy app", "reverse engineer this", "trace how X works". Trigger even when the word "legacy" is absent.
argument-hint: [module-or-flow]
allowed-tools: Read Grep Glob Bash(git ls-files *) Bash(git log *) Bash(wc *) Bash(grep *) Bash(find *) Bash(${CLAUDE_SKILL_DIR}/scripts/survey.sh *)
---

# Understand a Legacy Application

Build a durable mental model of an unfamiliar codebase the way a careful senior engineer would: top-down, evidence-based, documented as you go. The deliverable is `LEGACY_NOTES.md`, not just a chat answer.

## Repository survey (already gathered for you)

```!
bash ${CLAUDE_SKILL_DIR}/scripts/survey.sh
```

Use the survey above as your starting map. It lists the repo shape, build manifests, likely entry points, and risk markers. Don't re-run broad discovery that's already covered here.

## Principles

- Top-down before bottom-up. Establish architecture and entry points before reading individual functions. Reading files at random wastes context.
- Cite evidence. Every claim about behavior references `file:line`. Never describe behavior from assumption — locate the code that proves it.
- Document incrementally. Append findings to `LEGACY_NOTES.md` as you go, so understanding survives context compaction.
- Flag assumptions. When you infer rather than confirm, say so and note what would confirm it.
- Trust code over comments. Legacy comments are frequently stale.

## Workflow

1. Read the survey above and summarize the architecture: layers, frameworks, tech stack, how the pieces relate.
2. Confirm the entry points the survey found (main methods, controllers/routes, scheduled jobs, batch processes, queue consumers) and note any it missed.
3. Trace `$ARGUMENTS` if the user named a flow or module; otherwise pick 2–3 core flows and trace each end-to-end across files, recording the ordered call chain with `file:line` per hop.
4. Surface risk: dead code, duplication, oversized functions, untested critical paths, and the `TODO`/`FIXME`/`HACK` markers from the survey.
5. Write everything to `LEGACY_NOTES.md` using the template below (create it if absent, append if it exists).

## LEGACY_NOTES.md template

Write findings in exactly this structure:

```markdown
# Legacy Application Notes: [system name]

## Tech stack
- Language / framework / build tool / datastore

## Architecture overview
- Layers and how they relate (2–5 sentences)

## Entry points
| Entry point | Type | Location (file:line) | Purpose |
|-------------|------|----------------------|---------|

## Traced flows
### [Flow name]
1. `file:line` — what happens
2. `file:line` — what happens next

## Risk areas
- [ ] Dead code: `file:line` — note
- [ ] Duplication: locations — note
- [ ] Untested critical path: flow — note

## Open questions / assumptions
- Assumption made and why; what would confirm it
```

## Additional resources

- Stack-specific entry-point patterns and discovery commands: see [references/discovery.md](references/discovery.md).
