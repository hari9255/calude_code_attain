---
name: generate-uml
description: Generate accurate UML diagrams (class, sequence, component, state, ER) from actual source code as version-controllable diagram-as-code (Mermaid or PlantUML), saved under docs/uml/.
when_to_use: Use when the user asks to diagram, visualize the architecture, draw a class/sequence/component/state/ER diagram, show how classes relate, or map a flow as a diagram derived from real code. Trigger phrases include "diagram this module", "visualize the architecture", "draw a sequence diagram for X", "show the class structure".
argument-hint: [module-or-flow]
allowed-tools: Read Grep Glob Bash(mkdir *) Bash(npx @mermaid-js/mermaid-cli *)
---

# Generate UML from Code

Produce UML that reflects what the code actually does, expressed as diagram-as-code so it can be version-controlled, reviewed, and regenerated. Derive every diagram from parsed source — never from memory.

## Choose the diagram type

| The user wants to understand… | Use |
|-------------------------------|-----|
| Class structure, inheritance, fields/methods | Class diagram |
| A runtime flow: who calls whom, in order | Sequence diagram |
| Big-picture modules and boundaries | Component diagram |
| An object's lifecycle / status transitions | State diagram |
| Database schema and table relationships | ER diagram |

If the target is ambiguous, ask which question the user is trying to answer, then pick. Don't emit every diagram type by default.

## Principles

- Derive from source. Read the files in scope plus their direct collaborators; base the diagram on what's there. Mark any inferred relationship.
- Diagram-as-code only. Output Mermaid (default) or PlantUML. Never a binary image as the primary artifact.
- Scope per bounded context. One diagram per module. A whole-system diagram is unreadable — split it.
- Capture relationships fully: inheritance, associations, dependencies, and multiplicity/cardinality — not just boxes.
- Store in-repo. Save to `docs/uml/<name>.mmd` (or `.puml`) so diagrams live beside the code.

## Workflow

1. Confirm scope (`$ARGUMENTS` if the user named a module/flow), diagram type, and Mermaid vs PlantUML.
2. Read the relevant source and extract the model (types, fields, methods, relationships, multiplicity; or participants and ordered messages for sequences).
3. Emit readable diagram-as-code. Omit noise (getters/setters, framework boilerplate) unless exhaustive detail is requested.
4. `mkdir -p docs/uml` and save the diagram there. Tell the user the render command.
5. List any relationship inferred rather than proven from code.

## Render

```bash
# Mermaid → SVG
npx @mermaid-js/mermaid-cli -i docs/uml/<name>.mmd -o docs/uml/<name>.svg
```

## Quality checklist

- Every element corresponds to something real in the source.
- Multiplicities and relationship directions are correct.
- The diagram is scoped small enough to read.
- Saved in-repo as editable diagram-as-code.
- Inferred relationships are flagged.

## Additional resources

- Notation cheat-sheet for all five diagram types in Mermaid and PlantUML: see [references/notation.md](references/notation.md).
