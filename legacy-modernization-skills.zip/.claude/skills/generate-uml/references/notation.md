# UML notation cheat-sheet (Mermaid + PlantUML)

## Class diagram relationships

| Relationship | Mermaid | PlantUML |
|--------------|---------|----------|
| Inheritance | `A --|> B` | `B <|-- A` |
| Composition | `A *-- B` | `A *-- B` |
| Aggregation | `A o-- B` | `A o-- B` |
| Association | `A --> B` | `A --> B` |
| Dependency | `A ..> B` | `A ..> B` |
| Realization/interface | `A ..|> I` | `I <|.. A` |

Multiplicity in Mermaid: `A "1" --> "*" B : label`
Visibility: `+` public, `-` private, `#` protected, `~` package.

## Sequence diagram

Mermaid message arrows: `->>` sync call, `-->>` return, `-)` async, `--)` async return.
Blocks: `alt`/`else`/`end`, `loop`/`end`, `opt`/`end`, `par`/`and`/`end`.
Activation: `activate P` / `deactivate P`.

PlantUML: `A -> B : call`, `B --> A : return`, `alt cond ... else ... end`, `activate`/`deactivate`.

## Component diagram

Mermaid (use `flowchart` with subgraphs):
```mermaid
flowchart TB
  subgraph Web
    Ctrl[Controllers]
  end
  subgraph Domain
    Svc[Services]
  end
  Ctrl --> Svc
  Svc --> DB[(Database)]
```

PlantUML:
```plantuml
@startuml
package "Web" { [Controllers] }
package "Domain" { [Services] }
[Controllers] --> [Services]
[Services] --> [Database]
@enduml
```

## State diagram (Mermaid)
```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Submitted : submit
  Submitted --> Approved : approve
  Submitted --> Rejected : reject
  Approved --> [*]
```

## ER diagram (Mermaid)
```mermaid
erDiagram
  CUSTOMER ||--o{ ORDER : places
  ORDER ||--|{ LINE_ITEM : contains
  CUSTOMER {
    string id PK
    string email
  }
```

## Readability rules
- Cap ~15–20 elements per diagram; split larger ones by subsystem.
- Hide getters/setters and framework boilerplate unless exhaustive detail is requested.
- Name relationships (verbs) so the diagram reads as sentences.
