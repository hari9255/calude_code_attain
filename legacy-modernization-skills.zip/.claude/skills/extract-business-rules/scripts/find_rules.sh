#!/usr/bin/env bash
# Scan for likely business-rule sites. Read-only, best-effort.
set -euo pipefail

SRC='--include=*.java --include=*.cs --include=*.py --include=*.js --include=*.ts --include=*.rb --include=*.php --include=*.go --include=*.sql --include=*.cbl'

echo "## Validation & constraints"
grep -rniE '@(NotNull|NotEmpty|Min|Max|Size|Pattern|Valid)|validate|isValid|assert|required|CHECK ' $SRC . 2>/dev/null | head -25 || echo "(none)"

echo
echo "## Conditional / decision logic (sampled)"
grep -rniE 'if .*(>=|<=|==|>|<)|switch |case |EVALUATE |WHEN ' $SRC . 2>/dev/null | head -25 || echo "(none)"

echo
echo "## Calculations"
grep -rniE 'price|discount|tax|interest|rate|fee|total|amount|COMPUTE |score' $SRC . 2>/dev/null | head -25 || echo "(none)"

echo
echo "## Magic numbers (numeric literals in logic)"
grep -rnoE '[^A-Za-z_.][0-9]+\.?[0-9]*' $SRC . 2>/dev/null | grep -vE ':[0-9]+:[^0-9]*[01]$' | head -25 || echo "(none)"

echo
echo "## Stored procedures / triggers"
grep -rniE 'CREATE (OR REPLACE )?(PROCEDURE|FUNCTION|TRIGGER)' --include=*.sql . 2>/dev/null | head -20 || echo "(none)"
