---
name: extract-business-rules
description: Extract business rules buried in legacy code — validation, calculations, conditionals, eligibility/pricing/tax logic, stored procedures — into a structured, traceable BUSINESS_RULES.md catalog with source locations and confidence levels.
when_to_use: Use when the user wants to extract business rules, document business logic, reverse-engineer requirements from code, capture logic before a rewrite, or separate domain logic from technical plumbing. Trigger phrases include "extract business rules", "what rules does this enforce", "document the business logic", "what does this code decide", "capture the logic before we rewrite".
argument-hint: [domain-or-module]
allowed-tools: Read Grep Glob Bash(grep *) Bash(${CLAUDE_SKILL_DIR}/scripts/find_rules.sh *)
---

# Extract Business Rules

Recover the business intent encoded in legacy code so it survives a rewrite. The output is a structured, traceable catalog (`BUSINESS_RULES.md`) that a rewrite team and business owners can both trust.

## Candidate rule locations (pre-scanned)

```!
bash ${CLAUDE_SKILL_DIR}/scripts/find_rules.sh
```

The scan above points at likely rule sites (validations, conditionals, calculations, magic numbers, stored procedures). Start there, but read the surrounding code to understand each rule in context.

## Where rules hide

Validation logic; conditional branches (`if/else`, `switch`); calculations (pricing, discounts, tax, interest, scoring); eligibility/authorization; stored procedures and triggers; constants and magic numbers; state transitions.

## Principles

- Separate rules from plumbing. A line is a business rule if a non-technical owner would have an opinion about changing it (a threshold, an eligibility test, a fee). Logging, serialization, and defensive null-checks are plumbing.
- Make every rule traceable — record `file:line` (or procedure name) so reviewers can verify and the rewrite team can find it.
- Preserve edge cases — the exceptions, special cases, and magic numbers are exactly what a rewrite loses. Capture them with their apparent rationale.
- Surface conflicts — flag contradictory, redundant, or unreachable rules.
- Validate with humans — extracted rules are a draft of intent; recommend stakeholder review before reimplementation.

## Workflow

1. Scope to `$ARGUMENTS` if given (e.g. pricing, underwriting); otherwise pick one domain.
2. Work through the pre-scan sites and any stored procedures/triggers.
3. For each rule capture: stable ID, condition, action/outcome, source location, edge cases.
4. Classify: keep true business rules; annotate or discard plumbing.
5. Cross-check for contradictions, duplicates, and unreachable rules.
6. Map each rule to a business capability/user story where possible.
7. Write `BUSINESS_RULES.md` using the template below.
8. Recommend stakeholder validation before reimplementation.

## BUSINESS_RULES.md template

```markdown
# Business Rules Catalog: [domain]

## Rules
| ID | Rule (condition → action) | Source (file:line / proc) | Edge cases | Capability | Confidence |
|----|---------------------------|---------------------------|------------|------------|------------|
| BR-001 | If order total > $500 and customer is new → require manual review | OrderService.java:142 | Excludes wholesale | Fraud control | High |

## Calculations
| ID | What it computes | Formula / logic | Constants (with meaning) | Source |
|----|------------------|-----------------|--------------------------|--------|

## Magic numbers & thresholds
| Value | Meaning (inferred) | Where used | Confirmed? |
|-------|--------------------|-----------|------------|

## Conflicts, redundancies & dead rules
- [ ] BR-00X conflicts with BR-00Y because …

## Open questions for business owners
- Rule BR-00N: is this threshold still current policy?
```

## Conventions

- Phrase each rule as condition → action.
- Give every rule a stable ID (`BR-001`) so tests and the rewrite can reference it.
- Confidence: High = proven in code; Medium = inferred; Low = guessed, needs a human.
- Never normalize a weird rule into a "sensible" one — legacy quirks are often deliberate. Record as-is and flag.

## Additional resources

- Extraction patterns per language (including SQL and COBOL) and confidence calibration: see [references/patterns.md](references/patterns.md).
