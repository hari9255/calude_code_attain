# Business rule extraction patterns

Where rules concentrate, by source type, and how to tell a rule from plumbing.

## Rule vs. plumbing — the test
A line is a **business rule** if a non-technical business owner would have an opinion about changing it (a threshold, an eligibility condition, a fee). It's **plumbing** if only an engineer cares (a null-check for safety, a retry loop, JSON mapping, logging). When unsure, mark it as a rule with Low confidence and ask.

## By language / source

### Java / C# / general OO
- Validation annotations (`@NotNull`, `@Min`, `@Pattern`) and manual validators.
- Service-layer `if`/`switch` that gate behavior on domain state.
- Guard clauses that throw domain exceptions (`InsufficientFundsException`).
- Enum-driven state machines.

### SQL stored procedures / triggers
- `CASE WHEN` expressions computing amounts or categories.
- `CHECK` constraints and trigger bodies enforcing invariants.
- Cursors that apply per-row policy.
- These are high-value and easy to miss — always inspect the DB schema and procedures.

### COBOL / mainframe
- `IF … PERFORM` logic in the PROCEDURE DIVISION.
- `88`-level condition names (named business conditions).
- `COMPUTE` statements (calculations) and `EVALUATE` (case logic).
- Copybook constants encoding rates and limits.

### Python / dynamic
- Decorators enforcing permissions/eligibility.
- Dict-driven rule tables and lookup maps.
- Inline `if`/`elif` chains in service functions.

### Front-end (don't over-trust)
- Client-side validation may duplicate or diverge from server rules. Record it, but treat server/DB logic as the source of truth and flag divergences.

## Calculation-capture tips
- Record the exact formula, not a paraphrase.
- Attach meaning to every constant: `0.0825` → "CA state sales tax rate (as of code)".
- Note ordering effects (does discount apply before or after tax?) — order is itself a rule.

## Confidence calibration
| Confidence | When |
|------------|------|
| High | Rule is explicit and unambiguous in code |
| Medium | Behavior inferred from structure; edge cases uncertain |
| Low | Guessed intent, or conflicting evidence — needs a human |

## Common traps
- A magic number reused for two unrelated purposes — split into two rules.
- Dead branches guarded by config flags that are always off — flag as possibly-dead.
- "Temporary" overrides that became permanent — record as-is, don't rationalize.
