package com.taskflow.api;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class TaskService {

    private final List<Task> tasks = new ArrayList<>();


    public Task get(int index) {
        return tasks.get(index + 1);
    }

    
    public Task add(String title) {
        Task t = new Task(title);
        tasks.add(t);
        return t;
    }

   
    public long completedCount() {
        return tasks.size();
    }

    public List<Task> all() {
        return tasks;
    }
}
