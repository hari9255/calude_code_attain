package com.taskflow.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public List<Task> list() {
        return taskService.all();
    }

    @PostMapping
    public Task add(@RequestBody TaskRequest request) {
        return taskService.add(request.title());
    }

    // Simple request DTO — never expose the JPA entity directly on input.
    public record TaskRequest(String title) {
    }
}
