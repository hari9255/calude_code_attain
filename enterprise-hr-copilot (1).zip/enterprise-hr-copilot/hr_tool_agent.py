"""
hr_tool_agent.py
HR Tool Agent for the Enterprise HR Copilot.
Responsible for calling MCP tools based on the user's intent and resolved employee identity.
Handles: leave balance, employee search, holiday calendar, leave request creation.
"""

import re
from datetime import datetime
from typing import Optional

from mcp_client import mcp_client
from models import AgentState

# ── Intent-to-tool routing helpers ────

def _needs_leave_balance(message: str) -> bool:
    keywords = ["leave balance", "leaves left", "leaves remaining", "how many leaves",
                 "casual leave", "annual leave", "sick leave", "remaining leave"]
    msg = message.lower()
    return any(k in msg for k in keywords)


def _needs_holiday_calendar(message: str) -> bool:
    keywords = ["holiday", "holidays", "public holiday", "holiday calendar",
                 "upcoming holiday", "holiday list"]
    msg = message.lower()
    return any(k in msg for k in keywords)


def _needs_employee_search(message: str) -> bool:
    keywords = ["employee info", "employee profile", "who is", "find employee",
                 "search employee", "tell me about", "details of"]
    msg = message.lower()
    return any(k in msg for k in keywords)


def _needs_leave_request(message: str) -> bool:
    keywords = ["apply leave", "apply for leave", "create leave", "request leave",
                 "book leave", "take leave", "submit leave", "raise leave"]
    msg = message.lower()
    return any(k in msg for k in keywords)


# ── Date extraction helpers ────

def _extract_year(message: str) -> int:
    """
    Extracts a 4-digit year from the message.
    Falls back to the current year if none found.
    """
    match = re.search(r"\b(20\d{2})\b", message)
    if match:
        return int(match.group(1))
    return datetime.now().year


def _extract_dates(message: str) -> tuple[Optional[str], Optional[str]]:
    """
    Attempts to extract start and end dates from the message.
    Supports formats: YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY, DD Mon YYYY, Mon DD YYYY.

    Returns:
        Tuple of (start_date, end_date) as YYYY-MM-DD strings, or (None, None).
    """
    # Patterns to try
    patterns = [
        r"\b(\d{4}-\d{2}-\d{2})\b",           # YYYY-MM-DD
        r"\b(\d{2}-\d{2}-\d{4})\b",            # DD-MM-YYYY
        r"\b(\d{2}/\d{2}/\d{4})\b",            # DD/MM/YYYY
        r"\b(\d{1,2}\s+\w+\s+\d{4})\b",        # DD Mon YYYY
        r"\b(\w+\s+\d{1,2},?\s+\d{4})\b",      # Mon DD, YYYY
    ]

    date_formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%d %B %Y",
        "%d %b %Y",
        "%B %d %Y",
        "%B %d, %Y",
        "%b %d %Y",
        "%b %d, %Y",
    ]

    found_dates = []
    for pattern in patterns:
        matches = re.findall(pattern, message, re.IGNORECASE)
        for m in matches:
            for fmt in date_formats:
                try:
                    parsed = datetime.strptime(m.strip(), fmt)
                    found_dates.append(parsed.strftime("%Y-%m-%d"))
                    break
                except ValueError:
                    continue

    # Deduplicate while preserving order
    seen = []
    for d in found_dates:
        if d not in seen:
            seen.append(d)

    if len(seen) >= 2:
        return seen[0], seen[1]
    elif len(seen) == 1:
        return seen[0], seen[0]
    return None, None


def _extract_leave_type(message: str) -> str:
    """
    Extracts leave type from the message.
    Defaults to 'casual' if not determinable.
    """
    msg = message.lower()
    if "annual" in msg or "earned" in msg:
        return "annual"
    if "sick" in msg or "medical" in msg:
        return "sick"
    return "casual"


def _extract_reason(message: str) -> str:
    """
    Attempts to extract a reason from the message.
    Falls back to a generic reason.
    """
    patterns = [
        r"(?:reason[:\s]+)(.+?)(?:\.|$)",
        r"(?:for\s+)(.+?)(?:\.|$)",
        r"(?:due to\s+)(.+?)(?:\.|$)",
        r"(?:because\s+)(.+?)(?:\.|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            reason = match.group(1).strip()
            if len(reason) > 5:  # avoid capturing single words like "for leave"
                return reason
    return "Personal reasons"


# ── HR Tool Agent node function ────

def hr_tool_agent_node(state: AgentState) -> AgentState:
    """
    LangGraph node for the HR Tool Agent.

    Responsibilities:
    - Determine which MCP tools to call based on intent and message content.
    - Resolve employee identity before calling employee-specific tools.
    - Call MCP tools via mcp_client.
    - Store results in state.mcp_tool_results and state.mcp_tools_called.

    Args:
        state: Current LangGraph AgentState.

    Returns:
        Updated AgentState with mcp_tool_results, mcp_tools_called, and agent_flow updated.
    """
    print("[HRToolAgent] Invoked.")

    updates = state.model_copy()
    updates.agent_flow = state.agent_flow + ["HRToolAgent"]

    mcp_client.reset()
    tool_results = {}
    message = state.user_message

    # ── Holiday calendar (no identity needed) ────
    if _needs_holiday_calendar(message):
        year = _extract_year(message)
        print(f"[HRToolAgent] Calling holiday_calendar(year={year})")
        result = mcp_client.holiday_calendar(year=year)
        tool_results["holiday_calendar"] = result

    # ── Employee search (identity may or may not be self) ────
    if _needs_employee_search(message):
        if state.employee_id:
            print(f"[HRToolAgent] Calling search_employee(query={state.employee_id})")
            result = mcp_client.search_employee(query=state.employee_id)
        elif state.employee_name:
            print(f"[HRToolAgent] Calling search_employee(query={state.employee_name})")
            result = mcp_client.search_employee(query=state.employee_name)
        else:
            result = {"error": "Employee identity not provided for employee search."}
        tool_results["search_employee"] = result

    # ── Leave balance (requires identity) ────
    if _needs_leave_balance(message):
        if state.employee_id:
            print(f"[HRToolAgent] Calling get_leave_balance(employee_id={state.employee_id})")
            result = mcp_client.get_leave_balance(employee_id=state.employee_id)
        elif state.employee_name:
            # Resolve name to ID first
            print(f"[HRToolAgent] Resolving employee by name: {state.employee_name}")
            resolved = mcp_client.search_employee(query=state.employee_name)
            if "error" not in resolved:
                resolved_id = resolved.get("employee_id")
                updates.employee_id = resolved_id
                result = mcp_client.get_leave_balance(employee_id=resolved_id)
            else:
                result = resolved  # propagate the error
        else:
            result = {"error": "Employee identity not provided for leave balance check."}
        tool_results["get_leave_balance"] = result

    # ── Leave request creation (requires identity + dates) ────
    if _needs_leave_request(message):
        employee_id = state.employee_id

        # Try to resolve from name if ID not available
        if not employee_id and state.employee_name:
            print(f"[HRToolAgent] Resolving employee by name for leave request: {state.employee_name}")
            resolved = mcp_client.search_employee(query=state.employee_name)
            if "error" not in resolved:
                employee_id = resolved.get("employee_id")
                updates.employee_id = employee_id

        if not employee_id:
            tool_results["create_leave_request"] = {
                "error": "Employee identity not provided for leave request creation."
            }
        else:
            start_date, end_date = _extract_dates(message)
            leave_type = _extract_leave_type(message)
            reason = _extract_reason(message)

            if not start_date or not end_date:
                tool_results["create_leave_request"] = {
                    "error": (
                        "Could not extract leave dates from your message. "
                        "Please provide dates in YYYY-MM-DD format (e.g. 2026-08-12 to 2026-08-14)."
                    )
                }
            else:
                print(
                    f"[HRToolAgent] Calling create_leave_request("
                    f"employee_id={employee_id}, leave_type={leave_type}, "
                    f"start_date={start_date}, end_date={end_date})"
                )
                result = mcp_client.create_leave_request(
                    employee_id=employee_id,
                    leave_type=leave_type,
                    start_date=start_date,
                    end_date=end_date,
                    reason=reason,
                )
                tool_results["create_leave_request"] = result

    # ── If no specific tool was triggered, do a general employee lookup ────
    # This handles cases like "tool_only" intent with just an employee ID provided
    if not tool_results and (state.employee_id or state.employee_name):
        query = state.employee_id or state.employee_name
        print(f"[HRToolAgent] Fallback: calling search_employee(query={query})")
        result = mcp_client.search_employee(query=query)
        tool_results["search_employee"] = result

    updates.mcp_tool_results = tool_results
    updates.mcp_tools_called = mcp_client.tools_called

    print(f"[HRToolAgent] Tools called: {mcp_client.tools_called}")
    return updates