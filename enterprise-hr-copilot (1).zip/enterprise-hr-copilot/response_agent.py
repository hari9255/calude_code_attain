"""
response_agent.py
Response Agent for the Enterprise HR Copilot.
Synthesizes the final user-facing answer by combining policy context
and MCP tool results using the Groq LLM via LangChain ChatGroq.
"""

import os
from langchain_groq import ChatGroq
from langchain_core.output_parsers import StrOutputParser

from mcp_client import MCPClient
from models import AgentState
from prompts import RESPONSE_AGENT_PROMPT, GENERAL_RESPONSE_PROMPT, IDENTITY_CLARIFICATION_PROMPT

# ── LLM instance (loaded once) ────

_llm: ChatGroq = None


def get_llm() -> ChatGroq:
    """
    Returns a singleton ChatGroq LLM instance.
    Reads GROQ_API_KEY and GROQ_MODEL from environment variables.
    """
    global _llm
    if _llm is None:
        _llm = ChatGroq(
            model=os.getenv("GROQ_MODEL", "llama3-8b-8192"),
            temperature=0.3,
            groq_api_key=os.getenv("GROQ_API_KEY"),
        )
    return _llm


# ── Response Agent node function ────

def response_agent_node(state: AgentState) -> AgentState:
    """
    LangGraph node for the Response Agent.

    Responsibilities:
    - Determine the appropriate prompt based on intent and available context.
    - Combine policy context and MCP tool results into a single coherent answer.
    - Handle identity clarification responses when identity is missing.
    - Handle general/fallback responses for out-of-scope queries.
    - Store the final answer in state.final_response.

    Args:
        state: Current LangGraph AgentState.

    Returns:
        Updated AgentState with final_response and agent_flow updated.
    """
    print("[ResponseAgent] Invoked.")

    updates = state.model_copy()
    updates.agent_flow = state.agent_flow + ["ResponseAgent"]

    llm = get_llm()
    parser = StrOutputParser()

    # ── Case 1: Identity clarification needed ────
    if state.intent == "clarify_identity" or (state.needs_identity and not state.identity_resolved):
        print("[ResponseAgent] Generating identity clarification response.")
        try:
            chain = IDENTITY_CLARIFICATION_PROMPT | llm | parser
            response = chain.invoke({"user_message": state.user_message})
        except Exception as e:
            print(f"[ResponseAgent] LLM error during identity clarification: {e}")
            response = (
                "To help you with this request, I need to identify you first. "
                "Could you please provide your Employee ID (e.g. EMP001) or your full name?"
            )
        updates.final_response = response
        return updates

    # ── Case 2: General / out-of-scope query ────
    if state.intent == "general":
        print("[ResponseAgent] Generating general fallback response.")
        try:
            chain = GENERAL_RESPONSE_PROMPT | llm | parser
            response = chain.invoke({"user_message": state.user_message})
        except Exception as e:
            print(f"[ResponseAgent] LLM error during general response: {e}")
            response = (
                "Hello! I'm your Enterprise HR Copilot. I can help you with:\n"
                "- HR policy questions\n"
                "- Leave balance checks\n"
                "- Leave request creation\n"
                "- Employee information lookup\n"
                "- Holiday calendar\n\n"
                "How can I assist you today?"
            )
        updates.final_response = response
        return updates

    # ── Case 3: Policy / tool / hybrid response ────

    # Format MCP tool results into a readable string
    formatted_tool_results = MCPClient.format_results(state.mcp_tool_results)

    policy_context = state.policy_context or ""
    mcp_results_str = formatted_tool_results if state.mcp_tool_results else ""

    # If neither context nor tool results are available, return a graceful fallback
    if not policy_context and not mcp_results_str:
        print("[ResponseAgent] No context or tool results available. Returning fallback.")
        updates.final_response = (
            "I'm sorry, I wasn't able to find relevant information for your query. "
            "Please try rephrasing your question or contact HR directly for assistance."
        )
        return updates

    print(
        f"[ResponseAgent] Synthesizing response. "
        f"Policy context: {'yes' if policy_context else 'no'}, "
        f"Tool results: {'yes' if mcp_results_str else 'no'}"
    )

    try:
        chain = RESPONSE_AGENT_PROMPT | llm | parser
        response = chain.invoke({
            "user_message": state.user_message,
            "policy_context": policy_context if policy_context else "No policy context available.",
            "mcp_tool_results": mcp_results_str if mcp_results_str else "No tool results available.",
        })
    except Exception as e:
        print(f"[ResponseAgent] LLM error during synthesis: {e}")
        # Graceful degradation: return raw context/results if LLM fails
        parts = []
        if policy_context:
            parts.append(f"**Policy Information:**\n{policy_context}")
        if mcp_results_str:
            parts.append(f"**HR Data:**\n{mcp_results_str}")
        response = "\n\n".join(parts) if parts else (
            "I encountered an issue generating a response. Please try again."
        )

    updates.final_response = response
    return updates