"""
supervisor.py
Supervisor / Orchestrator for the Enterprise HR Copilot.
Defines the LangGraph state graph, intent classification node,
and routing logic to coordinate the Policy Retrieval Agent,
HR Tool Agent, and Response Agent.
"""

import os
import json
from typing import Literal
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END

from models import AgentState
from prompts import SUPERVISOR_INTENT_PROMPT
from retrieval_agent import retrieval_agent_node
from hr_tool_agent import hr_tool_agent_node
from response_agent import response_agent_node

load_dotenv()
# ── LLM instance (loaded once) ────

_llm: ChatGroq = None


def get_llm() -> ChatGroq:
    """
    Returns a singleton ChatGroq LLM instance for the Supervisor.
    """
    global _llm
    if _llm is None:
        _llm = ChatGroq(
            model=os.getenv("GROQ_MODEL", "llama3-8b-8192"),
            temperature=0.0,   # deterministic for intent classification
            groq_api_key=os.getenv("GROQ_API_KEY"),
        )
    return _llm


# ── Supervisor node: intent classification ────

def supervisor_node(state: AgentState) -> AgentState:
    """
    LangGraph node for the Supervisor Agent.

    Responsibilities:
    - Classify the user's intent using the LLM.
    - Extract employee_id / employee_name if mentioned.
    - Determine whether identity is needed and whether it is resolved.
    - Update AgentState with intent, needs_identity, identity_resolved.

    Args:
        state: Current LangGraph AgentState.

    Returns:
        Updated AgentState with intent classification results.
    """
    print("[Supervisor] Classifying intent...")

    updates = state.model_copy()
    updates.agent_flow = state.agent_flow + ["Supervisor"]

    llm = get_llm()

    try:
        chain = SUPERVISOR_INTENT_PROMPT | llm | StrOutputParser()
        raw_output = chain.invoke({"user_message": state.user_message})

        # Strip markdown fences if present
        cleaned = raw_output.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        cleaned = cleaned.strip()

        classification = json.loads(cleaned)

    except Exception as e:
        print(f"[Supervisor] Intent classification failed: {e}. Defaulting to 'general'.")
        classification = {
            "intent": "general",
            "needs_identity": False,
            "employee_id": None,
            "employee_name": None,
        }

    intent = classification.get("intent", "general")
    needs_identity = classification.get("needs_identity", False)
    extracted_id = classification.get("employee_id")
    extracted_name = classification.get("employee_name")

    # ── Merge extracted identity with any already present in state ────
    # State-level identity (passed in from API/session) takes precedence
    employee_id = state.employee_id or extracted_id
    employee_name = state.employee_name or extracted_name

    # ── Determine if identity is resolved ────
    identity_resolved = bool(employee_id or employee_name)

    # ── If identity is needed but not resolved, override intent ────
    if needs_identity and not identity_resolved:
        print("[Supervisor] Identity required but not resolved. Routing to clarify_identity.")
        intent = "clarify_identity"

    updates.intent = intent
    updates.needs_identity = needs_identity
    updates.identity_resolved = identity_resolved
    updates.employee_id = employee_id
    updates.employee_name = employee_name

    print(f"[Supervisor] Intent: {intent} | needs_identity: {needs_identity} | resolved: {identity_resolved}")
    return updates


# ── Routing function ────

def route_after_supervisor(
    state: AgentState,
) -> Literal["retrieval_agent", "hr_tool_agent", "both_retrieval_then_tool", "response_agent"]:
    """
    Determines the next node after the Supervisor based on classified intent.

    Routing rules:
    - rag_only        → retrieval_agent
    - tool_only       → hr_tool_agent
    - hybrid          → both_retrieval_then_tool (retrieval first, then tool)
    - clarify_identity→ response_agent (directly, to ask for identity)
    - general         → response_agent (directly, for fallback response)

    Args:
        state: Current LangGraph AgentState after Supervisor node.

    Returns:
        Name of the next node to route to.
    """
    intent = state.intent

    if intent == "rag_only":
        return "retrieval_agent"
    elif intent == "tool_only":
        return "hr_tool_agent"
    elif intent == "hybrid":
        return "both_retrieval_then_tool"
    else:
        # clarify_identity or general → go straight to response
        return "response_agent"


def route_after_retrieval(
    state: AgentState,
) -> Literal["hr_tool_agent", "response_agent"]:
    """
    After retrieval agent runs (in hybrid flow), decides whether to
    also invoke the HR Tool Agent or go straight to response.

    Args:
        state: Current AgentState after retrieval node.

    Returns:
        Next node name.
    """
    if state.intent == "hybrid":
        return "hr_tool_agent"
    return "response_agent"


# ── Graph construction ────

def build_graph() -> StateGraph:
    """
    Constructs and compiles the LangGraph StateGraph for the HR Copilot workflow.

    Graph structure:
        START
          └─► supervisor_node
                ├─► retrieval_agent_node  ──► response_agent_node ──► END
                ├─► hr_tool_agent_node    ──► response_agent_node ──► END
                ├─► retrieval_agent_node  ──► hr_tool_agent_node  ──► response_agent_node ──► END  (hybrid)
                └─► response_agent_node   ──► END  (general / clarify_identity)

    Returns:
        Compiled LangGraph StateGraph.
    """
    # LangGraph requires a dict-based state schema; we use AgentState as a TypedDict-compatible model
    graph = StateGraph(AgentState)

    # ── Add nodes ────
    graph.add_node("supervisor", supervisor_node)
    graph.add_node("retrieval_agent", retrieval_agent_node)
    graph.add_node("hr_tool_agent", hr_tool_agent_node)
    graph.add_node("response_agent", response_agent_node)

    # ── Entry point ────
    graph.set_entry_point("supervisor")

    # ── Conditional routing after supervisor ────
    graph.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "retrieval_agent": "retrieval_agent",
            "hr_tool_agent": "hr_tool_agent",
            "both_retrieval_then_tool": "retrieval_agent",  # hybrid starts at retrieval
            "response_agent": "response_agent",
        },
    )

    # ── After retrieval: either go to tool (hybrid) or response (rag_only) ────
    graph.add_conditional_edges(
        "retrieval_agent",
        route_after_retrieval,
        {
            "hr_tool_agent": "hr_tool_agent",
            "response_agent": "response_agent",
        },
    )

    # ── After tool agent: always go to response ────
    graph.add_edge("hr_tool_agent", "response_agent")

    # ── After response: end ────
    graph.add_edge("response_agent", END)

    return graph.compile()


# ── Singleton compiled graph ────

_graph = None


def get_graph():
    """
    Returns the singleton compiled LangGraph graph.
    Builds it on first call.
    """
    global _graph
    if _graph is None:
        print("[Supervisor] Building LangGraph workflow...")
        _graph = build_graph()
        print("[Supervisor] Graph ready.")
    return _graph


# ── Main entry point for running a query ────

def run_query(
    user_message: str,
    employee_id: str = None,
    employee_name: str = None,
) -> AgentState:
    """
    Runs a user query through the full LangGraph workflow.

    Args:
        user_message : The user's input message.
        employee_id  : Optional pre-known employee ID (from session/API).
        employee_name: Optional pre-known employee name (from session/API).

    Returns:
        Final AgentState after the full workflow completes.
    """
    graph = get_graph()

    initial_state = AgentState(
        user_message=user_message,
        employee_id=employee_id,
        employee_name=employee_name,
    )

    print(f"\n[Supervisor] Running query: '{user_message}'")
    final_state = graph.invoke(initial_state)

    # LangGraph returns a dict when using Pydantic models as state
    if isinstance(final_state, dict):
        final_state = AgentState(**final_state)

    return final_state