"""
api.py
FastAPI backend for the Enterprise HR Copilot.
Exposes endpoints for chat, health checks, and policy ingestion.
"""

import time
from fastapi import FastAPI, HTTPException, BackgroundTasks
from models import ChatRequest, ChatResponse, HealthResponse, UploadResponse
from supervisor import run_query
from vectorstore import collection_exists_and_populated
from ingest import ingest_hr_policy
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="Enterprise HR Copilot API",
    description="Backend API for the Multi-Agent HR Copilot with RAG and MCP tools.",
    version="1.0.0"
)

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Check the health of the system components.
    """
    return HealthResponse(
        status="ok",
        vectorstore_ready=collection_exists_and_populated(),
        mcp_server_ready=True  # Simplification for prototype
    )

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Main chat endpoint to interact with the HR Copilot.
    """
    start_time = time.time()
    
    try:
        # Run the workflow through the Supervisor orchestrator
        final_state = run_query(
            user_message=request.message,
            employee_id=request.employee_id
        )
        
        execution_time = round(time.time() - start_time, 3)
        
        return ChatResponse(
            response=final_state.final_response or "I'm sorry, I couldn't generate a response.",
            agent_flow=final_state.agent_flow,
            mcp_tools_called=final_state.mcp_tools_called,
            sources=final_state.sources,
            response_time_seconds=execution_time
        )
        
    except Exception as e:
        print(f"[API] Error in chat endpoint: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while processing your request.")

@app.post("/upload", response_model=UploadResponse)
async def upload_policy():
    """
    Endpoint to trigger re-ingestion of the HR policy document into the vector store.
    """
    try:
        chunks_indexed = ingest_hr_policy(reset=True)
        return UploadResponse(
            filename="hr_policy.txt",
            chunks_indexed=chunks_indexed,
            message="HR Policy document successfully re-indexed into ChromaDB."
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {str(e)}")

@app.get("/agents")
async def get_agents():
    """
    Returns information about the multi-agent system.
    """
    return {
        "agents": ["Supervisor", "Policy Retrieval Agent", "HR Tool Agent", "Response Agent"],
        "architecture": "LangGraph multi-agent workflow"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)