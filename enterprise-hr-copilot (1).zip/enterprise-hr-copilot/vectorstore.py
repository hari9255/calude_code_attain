"""
vectorstore.py
Manages the ChromaDB vector store for HR policy documents.
Handles embedding generation using sentence-transformers and
exposes a LangChain Chroma vectorstore with as_retriever() for the Policy Retrieval Agent.
"""

from pathlib import Path
from typing import Optional

from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

# ── Constants ────

BASE_DIR = Path(__file__).parent
CHROMA_DB_PATH = str(BASE_DIR / "chroma_db")
COLLECTION_NAME = "hr_policy"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
DEFAULT_N_RESULTS = 4

# ── Embedding function (loaded once) ────

_embedding_function: Optional[HuggingFaceEmbeddings] = None


def get_embedding_function() -> HuggingFaceEmbeddings:
    """
    Returns a singleton LangChain HuggingFaceEmbeddings instance.
    Loads the model on first call.
    """
    global _embedding_function
    if _embedding_function is None:
        print(f"[VectorStore] Loading embedding model: {EMBEDDING_MODEL_NAME}")
        _embedding_function = HuggingFaceEmbeddings(
            model_name=EMBEDDING_MODEL_NAME,
            model_kwargs={"device": "cpu"},
            encode_kwargs={"normalize_embeddings": True},
        )
    return _embedding_function


# ── LangChain Chroma vectorstore (loaded once) ────

_vectorstore: Optional[Chroma] = None


def get_vectorstore() -> Chroma:
    """
    Returns a singleton LangChain Chroma vectorstore instance backed
    by the persistent ChromaDB at CHROMA_DB_PATH.
    """
    global _vectorstore
    if _vectorstore is None:
        print(f"[VectorStore] Connecting to ChromaDB at: {CHROMA_DB_PATH}")
        _vectorstore = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=get_embedding_function(),
            persist_directory=CHROMA_DB_PATH,
            collection_metadata={"hnsw:space": "cosine"},
        )
    return _vectorstore


# ── Index documents ────

def add_documents(
    chunks: list[str],
    metadatas: list[dict],
    ids: list[str],
) -> int:
    """
    Embeds and adds document chunks to the LangChain Chroma vectorstore.

    Args:
        chunks   : List of text chunks to index.
        metadatas: List of metadata dicts (one per chunk).
        ids      : List of unique string IDs (one per chunk).

    Returns:
        Number of chunks successfully added.
    """
    if not chunks:
        return 0

    vectorstore = get_vectorstore()
    vectorstore.add_texts(
        texts=chunks,
        metadatas=metadatas,
        ids=ids,
    )

    print(f"[VectorStore] Indexed {len(chunks)} chunks into collection '{COLLECTION_NAME}'.")
    return len(chunks)


# ── Retriever (as_retriever) ────

def get_retriever(n_results: int = DEFAULT_N_RESULTS):
    """
    Returns a LangChain retriever using the vectorstore's as_retriever() method.
    Used directly by the Policy Retrieval Agent.

    Args:
        n_results: Number of top documents to retrieve per query.

    Returns:
        A LangChain VectorStoreRetriever instance.
    """
    vectorstore = get_vectorstore()
    return vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": n_results},
    )


def retrieve_and_format(query: str, n_results: int = DEFAULT_N_RESULTS) -> tuple[str, list[str]]:
    """
    Runs a retrieval query using the as_retriever() method and formats
    the results into a context string and source list for the LLM prompt.

    Args:
        query    : The user query string.
        n_results: Number of top documents to retrieve.

    Returns:
        Tuple of:
            - context_str : Combined text context for the LLM prompt.
            - sources     : List of source label strings for UI display.
    """
    if not collection_exists_and_populated():
        print("[VectorStore] Collection is empty. No results returned.")
        return "", []

    retriever = get_retriever(n_results=n_results)
    docs = retriever.invoke(query)

    if not docs:
        return "", []

    context_parts = []
    sources = []

    for i, doc in enumerate(docs, start=1):
        context_parts.append(f"[Excerpt {i}]\n{doc.page_content}")

        meta = doc.metadata or {}
        source = meta.get("source", "HR Policy Document")
        section = meta.get("section", "")
        source_label = f"{source} — {section}" if section else source
        if source_label not in sources:
            sources.append(source_label)

    context_str = "\n\n".join(context_parts)
    return context_str, sources


# ── Collection management ────

def get_collection_count() -> int:
    """
    Returns the number of chunks currently indexed.
    Uses the LangChain Chroma vectorstore directly — no raw chromadb client needed.
    """
    vectorstore = get_vectorstore()
    # _collection is the underlying chromadb collection on the LangChain Chroma object
    return vectorstore._collection.count()


def delete_collection() -> None:
    """
    Deletes the HR policy collection and resets the in-memory singleton.
    Useful for re-ingestion from scratch.
    """
    global _vectorstore
    vectorstore = get_vectorstore()
    vectorstore._client.delete_collection(name=COLLECTION_NAME)
    _vectorstore = None  # reset singleton so next call recreates it
    print(f"[VectorStore] Collection '{COLLECTION_NAME}' deleted.")


def collection_exists_and_populated() -> bool:
    """
    Returns True if the collection exists and has at least one document.
    Used by the health check and startup logic.
    """
    try:
        count = get_collection_count()
        return count > 0
    except Exception:
        return False