# Enterprise HR Copilot — Session Summary

## 1. Project Goal

Build a **prototype/demo-quality Enterprise HR Copilot** based on the uploaded capstone problem statement.

The copilot should answer HR questions, retrieve HR policy information, check employee-specific data, show holiday calendar information, and create leave requests.

This is **not production-grade**, but it should be a clean, working end-to-end implementation.

---

## 2. Required Tech Stack

Use the following stack exactly as discussed:

- **Groq API**
- **LangChain**
- **ChatGroq**
- **LangGraph**
- **FastMCP**
- **FastAPI**
- **Streamlit**
- **ChromaDB**
- **sentence-transformers**
- **pydantic**

The workflow must be **multi-agent** and implemented using **LangGraph nodes and edges**.

---

## 3. Important Functional Requirement About Identity

Originally there was an assumption about a logged-in employee, but this was changed.

### Final rule:
If the user asks something that requires employee-specific information, the system must:

1. Check whether the user has already provided identifying information
2. If not, ask the user to provide:
   - employee ID, or
   - full name
3. Only after identification, fetch employee-specific information

### Do NOT:
- assume a default employee
- assume a single logged-in employee globally

This rule applies especially to:
- leave balance queries
- employee-specific leave requests
- personal HR info questions

---

## 4. Project Structure to Follow

Stick to the suggested project structure from the problem statement.

Expected structure:

```text
enterprise_hr_copilot/
│
├── data/
│   ├── hr_policy.txt
│   ├── employee_data.json
│   └── holidays.json
│
├── requirements.txt
├── models.py
├── prompts.py
├── mcp_server.py
├── mcp_client.py
├── vectorstore.py
├── ingest.py
├── retrieval_agent.py
├── hr_tool_agent.py
├── response_agent.py
├── supervisor.py
├── api.py
├── streamlit_app.py
└── utils.py

### 5. Mock Data Already Defined

The assistant already created the mock data content conceptually for the following files:

#### `data/hr_policy.txt`

Should contain realistic HR policy text including topics like:

- annual leave
- sick leave
- casual leave
- maternity/paternity leave
- holidays
- work from home / attendance
- code of conduct
- payroll-related policy references
- leave approval rules
- notice period / resignation basics

Plain text format preferred.

#### `data/employee_data.json`

Should contain realistic employee records and leave-related data.

Expected kinds of fields:

- `employee_id`
- `full_name`
- `email`
- `department`
- `designation`
- `manager`
- `location`
- `joining_date`
- `leave_balance`
- `leave_history` / `leave_requests`

#### `data/holidays.json`

Should contain realistic holiday calendar data, likely keyed by year and location if needed.

### 6. MCP Tools That Must Exist

The HR tool layer should expose at least these MCP tools:

- `get_leave_balance(employee_id)`
- `search_employee(employee_name)`
- `holiday_calendar(year)`
- `create_leave_request(employee_id, leave_type, start_date, end_date, reason)`

These tools are part of the MCP-based integration design.

### 7. Architecture Decisions Finalized

#### Overall Architecture

A multi-agent HR copilot with:

- a policy retrieval path
- an HR tools/data access path
- a final response synthesis path

#### Agents / Modules

The system is expected to have the following logical components:

##### 1. Policy Retrieval Agent

Responsible for:

- querying the vector database
- retrieving relevant HR policy chunks
- providing context for policy-related answers

##### 2. HR Tool Agent

Responsible for:

- employee lookup
- leave balance lookup
- holiday lookup
- leave request creation
- interacting through MCP tools

##### 3. Response Agent

Responsible for:

- producing final user-friendly responses
- combining retrieved policy context + HR tool outputs
- handling clarification prompts where needed

##### 4. Supervisor / Orchestrator

Responsible for:

- routing tasks
- deciding whether a question is:
  - policy-related
  - employee-data/tool-related
  - mixed
- triggering the appropriate agent nodes in LangGraph
- enforcing identification requirements before employee-specific actions

### 8. Vector Store Decision

There was an explicit correction made here.

#### Final decision for `vectorstore.py`

Do **not** use a custom raw `similarity_search()` function as the main retrieval interface.

Instead:

- use LangChain Chroma
- expose retrieval via the vector DB’s `as_retriever()` method

#### Important

The assistant earlier produced one `vectorstore.py` using custom Chroma querying, but that was rejected.

Then an updated version was produced to use:

- `langchain_chroma.Chroma`
- `langchain_huggingface.HuggingFaceEmbeddings`
- `as_retriever()`

#### Required behavior

- use persistent Chroma storage
- use `all-MiniLM-L6-v2` embeddings
- provide a retriever via `as_retriever()`
- support document ingestion
- support collection existence/count checks
- support delete/reset for re-ingestion

#### Caution

The updated `vectorstore.py` draft had a likely inconsistency:

it still referenced helper functions like `get_or_create_collection()` / `get_chroma_client()` in collection management even after moving to LangChain Chroma.

So when continuing in the new chat, the assistant should produce a clean corrected final version of `vectorstore.py` using `as_retriever()` consistently throughout.

### 9. Files Already Generated in This Session

The following files were already generated in earlier steps of the conversation:

- `requirements.txt`
- `models.py`
- `prompts.py`
- `mcp_server.py`
- `mcp_client.py`
- `vectorstore.py`

#### Important note

`vectorstore.py` should be treated as needing final cleanup/correction because the latest version switched to `as_retriever()` but appears internally inconsistent in some helper functions.

If needed, regenerate `vectorstore.py` cleanly before continuing with the remaining files.

### 10. Files Yet to Be Generated

The remaining files still to be created are:

- `ingest.py`
- `retrieval_agent.py`
- `hr_tool_agent.py`
- `response_agent.py`
- `supervisor.py`
- `api.py`
- `streamlit_app.py`
- `utils.py`

### 11. Expected Role of Remaining Files

#### `ingest.py`

Should:

- load `data/hr_policy.txt`
- split into chunks
- attach metadata
- push chunks into Chroma
- optionally support reset/rebuild

#### `retrieval_agent.py`

Should:

- use the vector store retriever
- retrieve policy context
- return structured retrieval results for LangGraph workflow

#### `hr_tool_agent.py`

Should:

- call MCP client/server tools
- perform employee search
- leave balance fetch
- holiday lookup
- leave request creation
- enforce or support identity resolution

#### `response_agent.py`

Should:

- take outputs from retrieval/tool nodes
- create final natural-language answer
- use Groq LLM via LangChain `ChatGroq`

#### `supervisor.py`

Should:

- define LangGraph state
- create node functions
- route user requests
- determine whether to invoke:
  - retrieval agent
  - HR tool agent
  - both
- handle missing employee identity by asking for clarification

#### `api.py`

Should:

- provide FastAPI endpoints
- expose a chat endpoint for the copilot
- initialize graph and dependencies

#### `streamlit_app.py`

Should:

- create a basic chat UI
- call FastAPI backend
- show answers, sources, and leave request results where relevant

#### `utils.py`

Should contain helper utilities such as:

- loading JSON/text data
- normalization helpers
- date parsing helpers
- employee identification helper logic if needed

### 12. Behavioral Expectations for the Copilot

The assistant in the new conversation should preserve these design expectations:

#### Query Types to Support

- HR policy Q&A
- employee leave balance checks
- holiday calendar queries
- leave request creation
- mixed questions combining policy + personal info

If query is policy-only:

- Use retrieval agent.

If query is employee-specific:

- Require identification first if missing.

If query is tool/data-based:

- Use MCP tools.

If query is mixed:

- Use both retrieval + tool agent, then synthesize response.

### 13. Suggested Implementation Style

- Keep code modular
- Use Pydantic models where appropriate
- Use LangGraph state-based orchestration
- Keep prototype simple but working
- Prefer readability over overengineering
- Include comments/docstrings
- Ensure components integrate cleanly

### 14. Important Instruction for the New Conversation

In the new conversation, continue by generating the remaining Python files one by one, following the same order:

1. `ingest.py`
2. `retrieval_agent.py`
3. `hr_tool_agent.py`
4. `response_agent.py`
5. `supervisor.py`
6. `api.py`
7. `streamlit_app.py`
8. `utils.py`

Before continuing, the new assistant should be aware that:

- the user does not want a custom raw similarity search interface in `vectorstore.py`
- retrieval should use `as_retriever()`
- identity must never be assumed
- the structure from the problem statement must be followed closely

### 15. One More Practical Note

If the new assistant depends on the exact earlier code for previously generated files, it may regenerate those files cleanly for consistency, especially:

- `vectorstore.py`

But unless necessary, the main task is to continue with the remaining files.