"""
mcp_server.py
FastMCP server exposing HR enterprise tools.
Run standalone with: python mcp_server.py
"""

import json
import os
import uuid
from datetime import datetime, date
from pathlib import Path

from fastmcp import FastMCP

# ── Load data files ───────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent

def _load_json(filename: str) -> dict:
    filepath = BASE_DIR / filename
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(filename: str, data: dict) -> None:
    filepath = BASE_DIR / filename
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


# ── MCP Server instance ───────────────────────────────────────────────────────

mcp = FastMCP(
    name="Enterprise HR MCP Server",
    instructions="Provides HR tools: leave balance, employee search, holiday calendar, leave request creation.",
)


# ── Tool 1: get_leave_balance ─────────────────────────────────────────────────

@mcp.tool()
def get_leave_balance(employee_id: str) -> dict:
    """
    Returns the annual, casual, and sick leave balance for a given employee.

    Args:
        employee_id: The unique employee ID (e.g. EMP001).

    Returns:
        A dict containing employee name and leave balances, or an error message.
    """
    data = _load_json("employee_data.json")
    employees = data.get("employees", [])

    employee = next(
        (e for e in employees if e["employee_id"].upper() == employee_id.upper()),
        None,
    )

    if not employee:
        return {"error": f"Employee with ID '{employee_id}' not found."}

    balance = employee["leave_balance"]
    return {
        "employee_id": employee["employee_id"],
        "full_name": employee["full_name"],
        "leave_balance": {
            "annual": {
                "total": balance["annual"]["total"],
                "used": balance["annual"]["used"],
                "available": balance["annual"]["available"],
            },
            "casual": {
                "total": balance["casual"]["total"],
                "used": balance["casual"]["used"],
                "available": balance["casual"]["available"],
            },
            "sick": {
                "total": balance["sick"]["total"],
                "used": balance["sick"]["used"],
                "available": balance["sick"]["available"],
            },
        },
    }


# ── Tool 2: search_employee ───────────────────────────────────────────────────

@mcp.tool()
def search_employee(query: str) -> dict:
    """
    Searches for an employee by full name or employee ID.

    Args:
        query: Employee full name (e.g. 'Aarav Sharma') or employee ID (e.g. 'EMP001').

    Returns:
        A dict containing the employee profile, or an error message.
    """
    data = _load_json("employee_data.json")
    employees = data.get("employees", [])

    query_clean = query.strip().upper()

    # Try exact employee ID match first
    employee = next(
        (e for e in employees if e["employee_id"].upper() == query_clean),
        None,
    )

    # Fall back to case-insensitive name match
    if not employee:
        employee = next(
            (e for e in employees if e["full_name"].upper() == query.strip().upper()),
            None,
        )

    # Partial name match as last resort
    if not employee:
        employee = next(
            (
                e
                for e in employees
                if query.strip().lower() in e["full_name"].lower()
            ),
            None,
        )

    if not employee:
        return {"error": f"No employee found matching '{query}'."}

    return {
        "employee_id": employee["employee_id"],
        "full_name": employee["full_name"],
        "email": employee["email"],
        "department": employee["department"],
        "designation": employee["designation"],
        "employment_type": employee["employment_type"],
        "employment_status": employee["employment_status"],
        "date_of_joining": employee["date_of_joining"],
        "office_location": employee["office_location"],
        "manager_name": employee.get("manager_name"),
    }


# ── Tool 3: holiday_calendar ──────────────────────────────────────────────────

@mcp.tool()
def holiday_calendar(year: int) -> dict:
    """
    Returns the company holiday calendar for a given year.

    Args:
        year: The calendar year (e.g. 2026).

    Returns:
        A dict containing the list of holidays for that year, or an error message.
    """
    data = _load_json("holidays.json")
    calendars = data.get("holiday_calendars", {})
    year_key = str(year)

    if year_key not in calendars:
        return {
            "error": f"Holiday calendar for year {year} is not available.",
            "available_years": list(calendars.keys()),
        }

    return {
        "organization": data.get("organization"),
        "year": year,
        "total_holidays": len(calendars[year_key]),
        "holidays": calendars[year_key],
    }


# ── Tool 4: create_leave_request ──────────────────────────────────────────────

@mcp.tool()
def create_leave_request(
    employee_id: str,
    leave_type: str,
    start_date: str,
    end_date: str,
    reason: str,
) -> dict:
    """
    Creates a leave request for an employee and returns a request ID.

    Args:
        employee_id : Employee ID of the requester (e.g. EMP001).
        leave_type  : One of 'annual', 'casual', or 'sick'.
        start_date  : Leave start date in YYYY-MM-DD format.
        end_date    : Leave end date in YYYY-MM-DD format.
        reason      : Reason for the leave request.

    Returns:
        A dict with the generated request ID and status, or an error message.
    """
    data = _load_json("employee_data.json")
    employees = data.get("employees", [])
    holidays_data = _load_json("holidays.json")

    # ── Validate employee ──────────────────────────────────────────────────────
    employee = next(
        (e for e in employees if e["employee_id"].upper() == employee_id.upper()),
        None,
    )
    if not employee:
        return {"error": f"Employee with ID '{employee_id}' not found."}

    # ── Validate leave type ────────────────────────────────────────────────────
    valid_leave_types = ["annual", "casual", "sick"]
    if leave_type.lower() not in valid_leave_types:
        return {
            "error": f"Invalid leave type '{leave_type}'. Must be one of: {valid_leave_types}."
        }

    # ── Parse dates ────────────────────────────────────────────────────────────
    try:
        start = datetime.strptime(start_date, "%Y-%m-%d").date()
        end = datetime.strptime(end_date, "%Y-%m-%d").date()
    except ValueError:
        return {"error": "Invalid date format. Use YYYY-MM-DD."}

    if end < start:
        return {"error": "End date cannot be before start date."}

    # ── Calculate chargeable days (exclude weekends and holidays) ──────────────
    year_key = str(start.year)
    holiday_dates = set()
    if year_key in holidays_data.get("holiday_calendars", {}):
        for h in holidays_data["holiday_calendars"][year_key]:
            holiday_dates.add(h["date"])

    chargeable_days = 0
    current = start
    while current <= end:
        # 5 = Saturday, 6 = Sunday
        if current.weekday() < 5 and current.isoformat() not in holiday_dates:
            chargeable_days += 1
        current = date.fromordinal(current.toordinal() + 1)

    if chargeable_days == 0:
        return {
            "error": "The selected date range contains no chargeable working days (all weekends or holidays)."
        }

    # ── Validate leave balance ─────────────────────────────────────────────────
    available = employee["leave_balance"][leave_type.lower()]["available"]
    if chargeable_days > available:
        return {
            "error": (
                f"Insufficient {leave_type} leave balance. "
                f"Requested: {chargeable_days} days, Available: {available} days."
            )
        }

    # ── Generate request ID ────────────────────────────────────────────────────
    existing_requests = data.get("leave_requests", [])
    new_index = len(existing_requests) + 1
    request_id = f"LR-{start.year}-{new_index:04d}"

    # ── Create and persist the request ────────────────────────────────────────
    new_request = {
        "request_id": request_id,
        "employee_id": employee["employee_id"],
        "leave_type": leave_type.lower(),
        "start_date": start_date,
        "end_date": end_date,
        "chargeable_days": chargeable_days,
        "reason": reason,
        "status": "Pending",
        "created_at": datetime.now().isoformat(),
    }

    data["leave_requests"].append(new_request)

    # Deduct from balance
    employee["leave_balance"][leave_type.lower()]["used"] += chargeable_days
    employee["leave_balance"][leave_type.lower()]["available"] -= chargeable_days

    _save_json("employee_data.json", data)

    return {
        "request_id": request_id,
        "employee_id": employee["employee_id"],
        "full_name": employee["full_name"],
        "leave_type": leave_type.lower(),
        "start_date": start_date,
        "end_date": end_date,
        "chargeable_days": chargeable_days,
        "reason": reason,
        "status": "Pending",
        "message": (
            f"Leave request {request_id} created successfully. "
            f"Status is Pending and awaiting manager approval."
        ),
    }


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    mcp.run(transport="stdio")