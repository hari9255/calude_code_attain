"""
ingest.py
Handles ingestion of HR policy documents into the ChromaDB vector store.
Loads hr_policy.txt, splits it into chunks, attaches metadata, and indexes via vectorstore.py.
"""

import hashlib
from pathlib import Path
from typing import Optional

from vectorstore import add_documents, delete_collection, collection_exists_and_populated

# ── Constants ────

BASE_DIR = Path(__file__).parent
HR_POLICY_FILE = BASE_DIR / "data" / "hr_policy.txt"

CHUNK_SIZE = 500        # characters per chunk
CHUNK_OVERLAP = 100     # overlap between consecutive chunks to preserve context


# ── Text splitting ────

def split_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """
    Splits a plain text string into overlapping chunks of roughly chunk_size characters.
    Tries to split at paragraph or sentence boundaries where possible.

    Args:
        text      : Full document text.
        chunk_size: Target character length per chunk.
        overlap   : Number of characters to overlap between chunks.

    Returns:
        List of text chunk strings.
    """
    # Prefer splitting at double newlines (paragraph boundaries)
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

    chunks = []
    current_chunk = ""

    for para in paragraphs:
        # If adding this paragraph keeps us under chunk_size, append it
        if len(current_chunk) + len(para) + 2 <= chunk_size:
            current_chunk = (current_chunk + "\n\n" + para).strip()
        else:
            # Save current chunk if non-empty
            if current_chunk:
                chunks.append(current_chunk)

            # If the paragraph itself is larger than chunk_size, hard-split it
            if len(para) > chunk_size:
                start = 0
                while start < len(para):
                    end = start + chunk_size
                    chunks.append(para[start:end].strip())
                    start += chunk_size - overlap
            else:
                # Start a new chunk with overlap from the end of the previous chunk
                if chunks:
                    overlap_text = chunks[-1][-overlap:].strip()
                    current_chunk = (overlap_text + "\n\n" + para).strip()
                else:
                    current_chunk = para

    # Don't forget the last chunk
    if current_chunk:
        chunks.append(current_chunk)

    return [c for c in chunks if c]


# ── Metadata and ID generation ────

def _make_chunk_id(source: str, index: int, text: str) -> str:
    """
    Generates a stable unique ID for a chunk using source name, index, and a short content hash.

    Args:
        source: Source filename string.
        index : Chunk index integer.
        text  : Chunk text content.

    Returns:
        A unique string ID.
    """
    content_hash = hashlib.md5(text.encode()).hexdigest()[:8]
    return f"{source}_chunk_{index:04d}_{content_hash}"


def _make_metadata(source: str, index: int, total: int, section_hint: str = "") -> dict:
    """
    Builds a metadata dict for a chunk.

    Args:
        source      : Source filename.
        index       : Chunk index.
        total       : Total number of chunks in the document.
        section_hint: Optional section heading detected near this chunk.

    Returns:
        Metadata dict.
    """
    meta = {
        "source": source,
        "chunk_index": index,
        "total_chunks": total,
    }
    if section_hint:
        meta["section"] = section_hint
    return meta


def _detect_section(chunk: str) -> str:
    """
    Attempts to detect a section heading from the chunk text.
    Looks for lines that are short, title-cased, or all-caps — typical of headings.

    Args:
        chunk: Chunk text.

    Returns:
        Detected section heading string, or empty string if none found.
    """
    lines = chunk.strip().splitlines()
    for line in lines[:3]:  # check only the first 3 lines
        line = line.strip()
        if not line:
            continue
        # Heuristic: short line (< 80 chars), not ending with a period, looks like a heading
        if len(line) < 80 and not line.endswith(".") and (line.istitle() or line.isupper()):
            return line
    return ""


# ── Main ingestion function ────

def ingest_hr_policy(
    filepath: Optional[Path] = None,
    reset: bool = False,
) -> int:
    """
    Loads the HR policy text file, splits it into chunks, and indexes them into ChromaDB.

    Args:
        filepath: Path to the HR policy text file. Defaults to data/hr_policy.txt.
        reset   : If True, deletes the existing collection before re-ingesting.

    Returns:
        Number of chunks indexed.
    """
    filepath = filepath or HR_POLICY_FILE

    if not filepath.exists():
        raise FileNotFoundError(f"[Ingest] HR policy file not found: {filepath}")

    # ── Optionally reset the collection ────
    if reset:
        print("[Ingest] Resetting existing collection before re-ingestion...")
        delete_collection()

    # ── Skip if already populated (unless reset) ────
    if not reset and collection_exists_and_populated():
        print("[Ingest] Collection already populated. Skipping ingestion. Use reset=True to re-ingest.")
        return 0

    # ── Load text ────
    print(f"[Ingest] Loading HR policy from: {filepath}")
    text = filepath.read_text(encoding="utf-8")

    if not text.strip():
        raise ValueError("[Ingest] HR policy file is empty.")

    # ── Split into chunks ────
    chunks = split_text(text)
    total = len(chunks)
    print(f"[Ingest] Split into {total} chunks.")

    # ── Build metadata and IDs ────
    source_name = filepath.name
    texts = []
    metadatas = []
    ids = []

    for i, chunk in enumerate(chunks):
        section = _detect_section(chunk)
        chunk_id = _make_chunk_id(source_name, i, chunk)
        meta = _make_metadata(source_name, i, total, section_hint=section)

        texts.append(chunk)
        metadatas.append(meta)
        ids.append(chunk_id)

    # ── Index into ChromaDB ────
    indexed = add_documents(chunks=texts, metadatas=metadatas, ids=ids)
    print(f"[Ingest] Ingestion complete. {indexed} chunks indexed.")
    return indexed


# ── Entry point ────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Ingest HR policy documents into ChromaDB.")
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete existing collection and re-ingest from scratch.",
    )
    parser.add_argument(
        "--file",
        type=str,
        default=None,
        help="Path to HR policy text file. Defaults to data/hr_policy.txt.",
    )
    args = parser.parse_args()

    filepath = Path(args.file) if args.file else None
    count = ingest_hr_policy(filepath=filepath, reset=args.reset)
    print(f"[Ingest] Done. Total chunks indexed: {count}")