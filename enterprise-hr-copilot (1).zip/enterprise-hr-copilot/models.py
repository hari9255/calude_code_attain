"""
models.py
Pydantic models for request/response schemas used across the application.
"""

from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import date


# ── Chat ──────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str = Field(..., description="User's chat message")
    employee_id: Optional[str] = Field(None, description="Employee ID if already known")
    session_id: Optional[str] = Field(None, description="Session identifier for conversation continuity")


class ChatResponse(BaseModel):
    response: str = Field(..., description="Final answer from the HR Copilot")
    agent_flow: list[str] = Field(default_factory=list, description="List of agents invoked in order")
    mcp_tools_called: list[str] = Field(default_factory=list, description="MCP tools that were called")
    sources: list[str] = Field(default_factory=list, description="Policy document sources used")
    response_time_seconds: float = Field(..., description="Total response time in seconds")


# ── Leave Request ─────────────────────────────────────────────────────────────

class LeaveRequestInput(BaseModel):
    employee_id: str = Field(..., description="Employee ID of the requester")
    leave_type: Literal["annual", "casual", "sick"] = Field(..., description="Type of leave")
    start_date: date = Field(..., description="Leave start date (YYYY-MM-DD)")
    end_date: date = Field(..., description="Leave end date (YYYY-MM-DD)")
    reason: str = Field(..., description="Reason for leave")


class LeaveRequestOutput(BaseModel):
    request_id: str = Field(..., description="Generated leave request ID")
    employee_id: str
    leave_type: str
    start_date: str
    end_date: str
    chargeable_days: int
    reason: str
    status: Literal["Pending", "Approved", "Rejected"] = "Pending"
    message: str


# ── Employee ──────────────────────────────────────────────────────────────────

class EmployeeProfile(BaseModel):
    employee_id: str
    full_name: str
    email: str
    department: str
    designation: str
    employment_type: str
    employment_status: str
    date_of_joining: str
    office_location: str
    manager_name: Optional[str] = None


class LeaveBalance(BaseModel):
    employee_id: str
    full_name: str
    annual_total: int
    annual_used: int
    annual_available: int
    casual_total: int
    casual_used: int
    casual_available: int
    sick_total: int
    sick_used: int
    sick_available: int


# ── Upload ────────────────────────────────────────────────────────────────────

class UploadResponse(BaseModel):
    filename: str
    chunks_indexed: int
    message: str


# ── Health ────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    vectorstore_ready: bool
    mcp_server_ready: bool


# ── Agent State (LangGraph) ───────────────────────────────────────────────────

class AgentState(BaseModel):
    """
    Shared state passed between LangGraph nodes.
    """
    user_message: str = ""
    employee_id: Optional[str] = None
    employee_name: Optional[str] = None
    intent: Optional[str] = None                        # rag_only | tool_only | hybrid | clarify_identity | general
    needs_identity: bool = False
    identity_resolved: bool = False
    policy_context: Optional[str] = None
    mcp_tool_results: dict = Field(default_factory=dict)
    mcp_tools_called: list[str] = Field(default_factory=list)
    agent_flow: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)
    final_response: Optional[str] = None
    error: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True