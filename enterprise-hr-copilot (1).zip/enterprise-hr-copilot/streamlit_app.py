"""
streamlit_app.py
Streamlit frontend for the Enterprise HR Copilot.
Provides a chat interface, agent execution flow visualization, and source tracking.
"""

import streamlit as st
import requests
import time
from datetime import datetime

# ── Configuration ────

API_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="Enterprise HR Copilot",
    page_icon="💼",
    layout="wide"
)

# ── Session State Initialization ────

if "messages" not in st.session_state:
    st.session_state.messages = []

if "employee_id" not in st.session_state:
    st.session_state.employee_id = None

# ── Sidebar ────

with st.sidebar:
    st.title("⚙️ Settings & Info")
    
    st.session_state.employee_id = st.text_input(
        "Employee ID (Optional)", 
        value=st.session_state.employee_id,
        placeholder="e.g. EMP001"
    )
    
    st.divider()
    
    st.subheader("System Health")
    try:
        health_resp = requests.get(f"{API_URL}/health", timeout=20).json()
        if health_resp.get("status") == "ok":
            st.success("API: Online")
            if health_resp.get("vectorstore_ready"):
                st.success("Vector Store: Ready")
            else:
                st.warning("Vector Store: Empty")
        else:
            st.error("API: Issues detected")
    except:
        st.error("API: Offline (Run uvicorn api:app first)")

    st.divider()
    
    if st.button("🔄 Clear Chat"):
        st.session_state.messages = []
        st.rerun()
        
    if st.button("📥 Re-index Policy"):
        with st.spinner("Indexing..."):
            try:
                resp = requests.post(f"{API_URL}/upload").json()
                st.success(f"Indexed {resp['chunks_indexed']} chunks!")
            except:
                st.error("Indexing failed.")

# ── Main UI ────

st.title("💼 Enterprise HR Copilot")
st.markdown("""
Welcome! I am your HR assistant at **Nexora Technologies**.  
I can help with **policy questions**, **leave balances**, **holiday calendars**, and **applying for leave**.
""")

# Display Chat History
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if "metadata" in message:
            cols = st.columns(3)
            with cols[0]:
                st.caption(f"🧠 Agents: {' ➔ '.join(message['metadata']['flow'])}")
            with cols[1]:
                if message['metadata']['tools']:
                    st.caption(f"🛠️ Tools: {', '.join(message['metadata']['tools'])}")
            with cols[2]:
                st.caption(f"⏱️ Time: {message['metadata']['time']}s")

# Chat Input
if prompt := st.chat_input("How many casual leaves do I have?"):
    # Add user message to UI
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Call API
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        with st.spinner("Consulting HR agents..."):
            try:
                payload = {
                    "message": prompt,
                    "employee_id": st.session_state.employee_id
                }
                resp = requests.post(f"{API_URL}/chat", json=payload).json()
                
                full_response = resp["response"]
                response_placeholder.markdown(full_response)
                
                metadata = {
                    "flow": resp["agent_flow"],
                    "tools": resp["mcp_tools_called"],
                    "sources": resp["sources"],
                    "time": resp["response_time_seconds"]
                }
                
                # Show Sources if available
                if resp["sources"]:
                    with st.expander("View Policy Sources"):
                        for source in resp["sources"]:
                            st.write(f"• {source}")

                st.session_state.messages.append({
                    "role": "assistant", 
                    "content": full_response,
                    "metadata": metadata
                })

            except Exception as e:
                st.error(f"Communication error with the HR Backend. Please ensure `api.py` is running.")