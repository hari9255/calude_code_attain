"""
utils.py
General utility functions for the Enterprise HR Copilot.
Handles data loading, text normalization, and date formatting.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, Optional

# ── Path Helpers ────

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"

def get_data_path(filename: str) -> Path:
    """Returns the absolute path to a file in the data directory."""
    return DATA_DIR / filename


# ── JSON Helpers ────

def load_json_data(filename: str) -> Dict[str, Any]:
    """
    Safely loads JSON data from the data directory.
    Returns an empty dict if the file is not found.
    """
    path = get_data_path(filename)
    try:
        if not path.exists():
            print(f"[Utils] Warning: {filename} not found.")
            return {}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[Utils] Error loading {filename}: {e}")
        return {}


def save_json_data(filename: str, data: Dict[str, Any]) -> bool:
    """
    Saves a dictionary to a JSON file in the data directory.
    """
    path = get_data_path(filename)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        return True
    except Exception as e:
        print(f"[Utils] Error saving {filename}: {e}")
        return False


# ── String & Formatting Helpers ────

def normalize_string(text: str) -> str:
    """Standardizes string for comparison (lowercase, stripped)."""
    return text.strip().lower()


def format_date_display(date_str: str) -> str:
    """
    Converts YYYY-MM-DD to a more readable 'DD-Mon-YYYY' format.
    """
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        return dt.strftime("%d-%b-%Y")
    except:
        return date_str


# ── Identity Helper ────

def is_valid_employee_id(emp_id: Optional[str]) -> bool:
    """
    Basic validator for employee ID format (e.g., EMP followed by digits).
    """
    if not emp_id:
        return False
    # Simple check for the 'EMP' prefix used in the mock data
    return emp_id.strip().upper().startswith("EMP")


# ── Observability/Logging ────

def log_agent_action(agent_name: str, action_desc: str):
    """Simple console logger for agent steps."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] [{agent_name}] {action_desc}")


if __name__ == "__main__":
    # Quick test
    print(f"Data directory: {DATA_DIR}")
    test_id = "emp001"
    print(f"Is {test_id} valid? {is_valid_employee_id(test_id)}")