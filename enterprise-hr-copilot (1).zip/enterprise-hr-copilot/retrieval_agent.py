"""
retrieval_agent.py
Policy Retrieval Agent for the Enterprise HR Copilot.
Queries the ChromaDB vector store using the as_retriever() interface
and returns structured policy context for the LangGraph workflow.
"""

from langchain_groq import ChatGroq
from langchain_core.output_parsers import StrOutputParser

from vectorstore import retrieve_and_format, collection_exists_and_populated
from prompts import RETRIEVAL_AGENT_PROMPT
from models import AgentState

# ── LLM instance (loaded once) ────

_llm: ChatGroq = None


def get_llm() -> ChatGroq:
    """
    Returns a singleton ChatGroq LLM instance.
    Model and API key are read from environment variables.
    """
    global _llm
    if _llm is None:
        import os
        _llm = ChatGroq(
            model=os.getenv("GROQ_MODEL", "llama3-8b-8192"),
            temperature=0.2,
            groq_api_key=os.getenv("GROQ_API_KEY"),
        )
    return _llm


# ── Retrieval Agent node function ────

def retrieval_agent_node(state: AgentState) -> AgentState:
    """
    LangGraph node for the Policy Retrieval Agent.

    Responsibilities:
    - Query ChromaDB using the user message as the search query.
    - Retrieve relevant HR policy excerpts.
    - Optionally run the retrieval prompt through the LLM for a focused policy answer.
    - Update AgentState with policy_context and sources.

    Args:
        state: Current LangGraph AgentState.

    Returns:
        Updated AgentState with policy_context, sources, and agent_flow updated.
    """
    print("[RetrievalAgent] Invoked.")

    updates = state.model_copy()
    updates.agent_flow = state.agent_flow + ["RetrievalAgent"]

    # ── Guard: check if vectorstore is populated ────
    if not collection_exists_and_populated():
        print("[RetrievalAgent] Vector store is empty. No policy context available.")
        updates.policy_context = ""
        updates.sources = []
        return updates

    # ── Retrieve relevant chunks ────
    query = state.user_message
    context_str, sources = retrieve_and_format(query=query)

    if not context_str:
        print("[RetrievalAgent] No relevant policy chunks found for query.")
        updates.policy_context = ""
        updates.sources = []
        return updates

    print(f"[RetrievalAgent] Retrieved context from {len(sources)} source(s).")

    # ── Run through LLM for a focused policy answer ────
    # This gives the Response Agent a pre-processed policy answer
    # rather than raw excerpts, making synthesis easier.
    try:
        llm = get_llm()
        chain = RETRIEVAL_AGENT_PROMPT | llm | StrOutputParser()
        policy_answer = chain.invoke({
            "policy_context": context_str,
            "user_message": query,
        })
        updates.policy_context = policy_answer
    except Exception as e:
        print(f"[RetrievalAgent] LLM call failed, falling back to raw context. Error: {e}")
        # Fall back to raw retrieved context if LLM call fails
        updates.policy_context = context_str

    updates.sources = sources
    return updates


# ── Standalone retrieval utility ────

def retrieve_policy_context(query: str) -> tuple[str, list[str]]:
    """
    Standalone utility to retrieve and return raw policy context and sources.
    Useful for testing or direct calls outside the LangGraph workflow.

    Args:
        query: User query string.

    Returns:
        Tuple of (context_str, sources).
    """
    if not collection_exists_and_populated():
        return "", []
    return retrieve_and_format(query=query)