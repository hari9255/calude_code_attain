# 💼 Enterprise HR Copilot — Multi-Agent MCP Capstone

A prototype Enterprise HR Copilot built using a **multi-agent architecture** with **RAG (Retrieval-Augmented Generation)**, **MCP (Model Context Protocol)** tools, **LangGraph** orchestration, a **FastAPI** backend, and a **Streamlit** frontend.

---

## 📌 Project Overview

The HR Copilot can:

- Answer HR policy questions using RAG over uploaded policy documents
- Check employee leave balances
- Create leave requests
- Look up employee profiles
- Retrieve the company holiday calendar
- Handle mixed queries combining policy + employee-specific data

---

## 🏗️ Architecture

```text
User Query
│
▼
Supervisor Agent (LangGraph)
│
├── rag_only ──► Policy Retrieval Agent ──────────────────────────► Response Agent
│                 (ChromaDB + HuggingFace Embeddings)
│
├── tool_only ──► HR Tool Agent ──────────────────────────────────► Response Agent
│                 (MCP Tools via FastMCP)
│
├── hybrid ──► Policy Retrieval Agent ──► HR Tool Agent ───────► Response Agent
│
└── general /
    clarify ──────────────────────────────────────────────────► Response Agent
```

### Agents

| Agent | Responsibility |
|---|---|
| **Supervisor Agent** | Classifies intent, routes requests to appropriate agents, and enforces the identity requirement. |
| **Policy Retrieval Agent** | Queries ChromaDB, retrieves HR policy excerpts, and pre-processes them with an LLM. |
| **HR Tool Agent** | Calls MCP tools for leave balances, employee search, holidays, and leave requests. |
| **Response Agent** | Synthesizes the final user-facing answer using policy context and tool results. |

### MCP Tools

| Tool | Description |
|---|---|
| `get_leave_balance(employee_id)` | Returns annual, casual, and sick leave balances. |
| `search_employee(query)` | Searches for an employee by name or ID. |
| `holiday_calendar(year)` | Returns the company holiday calendar for a specified year. |
| `create_leave_request(...)` | Creates a leave request and returns a request ID. |

## 📁 Project Structure

```text
enterprise_hr_copilot/
│
├── data/
│   ├── hr_policy.txt          # HR policy document (plain text)
│   ├── employee_data.json     # Mock employee records and leave data
│   └── holidays.json          # Company holiday calendar
│
├── chroma_db/                 # Auto-created by ChromaDB on first ingest
│
├── models.py                  # Pydantic models for requests, responses, and AgentState
├── prompts.py                 # Centralised LangChain prompt templates for all agents
├── vectorstore.py             # ChromaDB vector store management via LangChain Chroma
├── ingest.py                  # HR policy document ingestion pipeline
├── mcp_server.py              # FastMCP server exposing HR enterprise tools
├── mcp_client.py              # Client wrapper for MCP tool calls
├── retrieval_agent.py         # Policy Retrieval Agent (LangGraph node)
├── hr_tool_agent.py           # HR Tool Agent (LangGraph node)
├── response_agent.py          # Response Agent (LangGraph node)
├── supervisor.py              # Supervisor + LangGraph graph construction
├── api.py                     # FastAPI backend
├── streamlit_app.py           # Streamlit frontend
├── utils.py                   # Shared utility functions
└── requirements.txt           # Python dependencies
```

## ⚙️ Tech Stack

| Component | Technology |
|---|---|
| **LLM** | Groq API (`llama3-8b-8192`) via `langchain-groq` |
| **Agent Orchestration** | LangGraph |
| **Vector Store** | ChromaDB via `langchain-chroma` |
| **Embeddings** | `all-MiniLM-L6-v2` via `langchain-huggingface` / `sentence-transformers` |
| **MCP Server** | FastMCP |
| **Backend API** | FastAPI + Uvicorn |
| **Frontend** | Streamlit |
| **Data Validation** | Pydantic v2 |

## 🔧 Prerequisites

### 1. Python Version

Python **3.10 or higher** is required.

### 2. Groq API Key

Sign up at [Groq Console](https://console.groq.com) and obtain an API key.

### 3. Environment Variables

Create a `.env` file in the project root, or export the following variables:

```bash
export GROQ_API_KEY=your_groq_api_key_here
export GROQ_MODEL=llama3-8b-8192
```

Alternatively, create a `.env` file:

```dotenv
GROQ_API_KEY=your_groq_api_key_here
GROQ_MODEL=llama3-8b-8192
```

If using a `.env` file, install `python-dotenv` and add `load_dotenv()` at the top of both `api.py` and `supervisor.py`.

## 📦 Installation

### Step 1 — Set Up the Project Directory

```bash
mkdir enterprise_hr_copilot
cd enterprise_hr_copilot

# Place all .py files and the data/ folder here
```

### Step 2 — Create and Activate a Virtual Environment

```bash
python -m venv venv
source venv/bin/activate
```

On Windows:

```bash
venv\Scripts\activate
```

### Step 3 — Install Dependencies

```bash
pip install -r requirements.txt
```

Alternatively, install dependencies manually:

```bash
pip install fastapi uvicorn streamlit requests \
    langchain langchain-groq langchain-chroma langchain-huggingface \
    langgraph chromadb sentence-transformers \
    fastmcp pydantic
```

## 🚀 Running the Application

### Step 1 — Ingest the HR Policy Document

This loads `data/hr_policy.txt`, splits it into chunks, and indexes those chunks into ChromaDB.

```bash
python ingest.py
```

To force a complete re-index:

```bash
python ingest.py --reset
```

Example expected output:

```text
[VectorStore] Loading embedding model: all-MiniLM-L6-v2
[Ingest] Loading HR policy from: data/hr_policy.txt
[Ingest] Split into 42 chunks.
[VectorStore] Indexed 42 chunks into collection 'hr_policy'.
[Ingest] Ingestion complete. 42 chunks indexed.
```

### Step 2 — Start the FastAPI Backend

```bash
uvicorn api:app
```

The API will be available at `http://127.0.0.1:8000`.

Interactive API documentation is available at `http://127.0.0.1:8000/docs`.

### Step 3 — Launch the Streamlit Frontend

Open a new terminal while keeping the API running:

```bash
streamlit run streamlit_app.py
```

The Streamlit interface will open at `http://localhost:8501`.

## 🧪 Sample Queries

| Query | Expected Behaviour |
|---|---|
| What is the maternity leave policy? | RAG-only: retrieves relevant details from the HR policy document. |
| How many casual leaves do I have? | Requests an Employee ID or full name first. |
| How many casual leaves do I have? My ID is EMP001 | Calls the `get_leave_balance` MCP tool. |
| What is the leave policy and how many leaves do I still have? I am EMP002 | Hybrid: uses RAG and an MCP tool. |
| Apply casual leave from 2026-08-12 to 2026-08-14. My ID is EMP001 | Calls the `create_leave_request` MCP tool. |
| What are the holidays in 2026? | Calls the `holiday_calendar` MCP tool. |
| Tell me about employee Aarav Sharma | Calls the `search_employee` MCP tool. |
| Hello | Returns a general fallback response. |

## 🔑 Identity Resolution Rule

For any query requiring employee-specific data, the system must **never assume a default employee**.

If the user does not provide an Employee ID or full name, the system should respond politely:

> To help you with this, could you please provide your Employee ID (e.g. EMP001) or your full name?

Users can also pre-fill their Employee ID in the Streamlit sidebar to avoid being asked repeatedly.

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | System health check. |
| `POST` | `/chat` | Main chat endpoint. |
| `POST` | `/upload` | Re-indexes the HR policy into ChromaDB. |
| `GET` | `/agents` | Lists available agents. |

### Example `/chat` Request

```json
POST /chat
{
  "message": "How many annual leaves do I have? My ID is EMP001",
  "employee_id": "EMP001",
  "session_id": "optional-session-id"
}
```

### Example `/chat` Response

```json
{
  "response": "You currently have 8 annual leaves available out of 18 total.",
  "agent_flow": ["Supervisor", "HRToolAgent", "ResponseAgent"],
  "mcp_tools_called": ["get_leave_balance"],
  "sources": [],
  "response_time_seconds": 1.243
}
```

## 🗂️ Data Files

### `data/employee_data.json`

Contains employee records with fields including:

- `employee_id`
- `full_name`
- `email`
- `department`
- `designation`
- `employment_type`
- `employment_status`
- `date_of_joining`
- `office_location`
- `manager_name`
- `leave_balance`
  - Annual leave
  - Casual leave
  - Sick leave
- `leave_requests`

The `leave_requests` field is updated whenever a leave request is created.

### `data/holidays.json`

Contains holiday calendars keyed by year.

```json
{
  "organization": "Nexora Technologies",
  "holiday_calendars": {
    "2026": [
      {
        "date": "2026-01-26",
        "name": "Republic Day",
        "type": "National"
      }
    ]
  }
}
```

### `data/hr_policy.txt`

A plain-text HR policy document that covers:

- Annual, casual, sick, maternity, and paternity leave policies
- Leave approval rules
- Work-from-home and attendance policies
- Code of conduct
- Notice period and resignation basics

## 📊 Evaluation Criteria

| Component | Marks |
|---|---:|
| RAG Pipeline | 15 |
| ChromaDB Integration | 10 |
| Prompt Engineering | 10 |
| Multi-Agent Orchestration | 20 |
| MCP Server & Tools | 20 |
| FastAPI APIs | 10 |
| Streaming Responses | 5 |
| Streamlit UI | 5 |
| Code Quality & Documentation | 5 |
| **Total** | **100** |

## 🛠️ Troubleshooting

| Issue | Fix |
|---|---|
| `GROQ_API_KEY not set` | Export the environment variable or add it to `.env`. |
| Vector store is empty in the sidebar | Run `python ingest.py` first. |
| API appears offline in the sidebar | Start the backend with `python api.py`. |
| `ModuleNotFoundError` | Run `pip install -r requirements.txt`. |
| Collection is already populated during ingestion | Run `python ingest.py --reset` to force a re-index. |
| LangGraph state dictionary error | Ensure `AgentState` fields have proper defaults in `models.py`. |

## 📝 Notes

- This is a prototype or demo-quality implementation and is **not production-grade**.
- The MCP server and client run in-process through direct function imports for simplicity.
- In a production deployment, FastMCP would typically operate over `stdio` or HTTP transport.
- ChromaDB persists data locally in the `chroma_db/` folder. Delete this folder to start from a clean state.
- The Groq model can be changed through the `GROQ_MODEL` environment variable, for example `mixtral-8x7b-32768`.
- This project was built as part of the **Enterprise HR Copilot Multi-Agent MCP Capstone**.


