"""
mcp_client.py
Client wrapper that communicates with the MCP server tools.
Used by the HR Tool Agent to invoke MCP tools programmatically.
"""

import json
from pathlib import Path
from datetime import datetime, date


# ── Direct import of MCP tool functions ───────────────────────────────────────
# Since both server and client run in the same process for this prototype,
# we import the tool functions directly from mcp_server.
# In a production setup, this would use FastMCP's client over stdio/HTTP transport.

from mcp_server import (
    get_leave_balance,
    search_employee,
    holiday_calendar,
    create_leave_request,
)


class MCPClient:
    """
    Wrapper around MCP server tools.
    Provides a clean interface for the HR Tool Agent to call enterprise tools.
    Tracks which tools were called during a session.
    """

    def __init__(self):
        self.tools_called: list[str] = []

    def _record(self, tool_name: str) -> None:
        """Record a tool call for observability."""
        self.tools_called.append(tool_name)

    def reset(self) -> None:
        """Reset tool call history for a new request."""
        self.tools_called = []

    # ── Tool: get_leave_balance ────────────────────────────────────────────────

    def get_leave_balance(self, employee_id: str) -> dict:
        """
        Fetch leave balance for a given employee ID.

        Args:
            employee_id: Employee ID string (e.g. 'EMP001').

        Returns:
            Dict with leave balance details or error.
        """
        self._record("get_leave_balance")
        result = get_leave_balance(employee_id=employee_id)
        return result

    # ── Tool: search_employee ──────────────────────────────────────────────────

    def search_employee(self, query: str) -> dict:
        """
        Search for an employee by name or employee ID.

        Args:
            query: Full name or employee ID string.

        Returns:
            Dict with employee profile or error.
        """
        self._record("search_employee")
        result = search_employee(query=query)
        return result

    # ── Tool: holiday_calendar ─────────────────────────────────────────────────

    def holiday_calendar(self, year: int = None) -> dict:
        """
        Fetch the holiday calendar for a given year.
        Defaults to the current year if not specified.

        Args:
            year: Integer year (e.g. 2026). Defaults to current year.

        Returns:
            Dict with holiday list or error.
        """
        if year is None:
            year = datetime.now().year
        self._record("holiday_calendar")
        result = holiday_calendar(year=year)
        return result

    # ── Tool: create_leave_request ─────────────────────────────────────────────

    def create_leave_request(
        self,
        employee_id: str,
        leave_type: str,
        start_date: str,
        end_date: str,
        reason: str,
    ) -> dict:
        """
        Create a leave request for an employee.

        Args:
            employee_id : Employee ID string (e.g. 'EMP001').
            leave_type  : One of 'annual', 'casual', or 'sick'.
            start_date  : Start date string in YYYY-MM-DD format.
            end_date    : End date string in YYYY-MM-DD format.
            reason      : Reason for the leave.

        Returns:
            Dict with request ID and status, or error.
        """
        self._record("create_leave_request")
        result = create_leave_request(
            employee_id=employee_id,
            leave_type=leave_type,
            start_date=start_date,
            end_date=end_date,
            reason=reason,
        )
        return result

    # ── Resolve employee identity ──────────────────────────────────────────────

    def resolve_employee(self, employee_id: str = None, employee_name: str = None) -> dict:
        """
        Resolve an employee record from either an ID or a name.
        Returns the employee profile dict or an error dict.

        Args:
            employee_id  : Optional employee ID.
            employee_name: Optional employee name.

        Returns:
            Dict with employee profile or error.
        """
        if employee_id:
            return self.search_employee(query=employee_id)
        elif employee_name:
            return self.search_employee(query=employee_name)
        else:
            return {"error": "No employee identifier provided."}

    # ── Utility: format tool results for LLM ──────────────────────────────────

    @staticmethod
    def format_results(tool_results: dict) -> str:
        """
        Converts the MCP tool results dict into a readable string
        for passing into the Response Agent prompt.

        Args:
            tool_results: Dict of {tool_name: result_dict}.

        Returns:
            Formatted string representation.
        """
        if not tool_results:
            return "No tool results available."

        lines = []
        for tool_name, result in tool_results.items():
            lines.append(f"[{tool_name}]")
            if isinstance(result, dict):
                lines.append(json.dumps(result, indent=2, default=str))
            else:
                lines.append(str(result))
            lines.append("")

        return "\n".join(lines)


# ── Singleton instance ─────────────────────────────────────────────────────────
# Shared across the application so tool call history is accessible.

mcp_client = MCPClient()