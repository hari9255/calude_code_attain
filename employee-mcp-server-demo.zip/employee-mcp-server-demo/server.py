import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Employee Demo MCP")

DATA_FILE = Path(__file__).parent / "employees.json"


def load_employees():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


@mcp.tool()
def get_employee(employee_id: str):
    """
    Get employee details using employee id.
    """

    employees = load_employees()

    for emp in employees:
        if emp["employee_id"].lower() == employee_id.lower():
            return emp

    return {"message": "Employee not found"}


@mcp.tool()
def search_employee(name: str):
    """
    Search employee by name.
    """

    employees = load_employees()

    result = []

    for emp in employees:
        if name.lower() in emp["name"].lower():
            result.append(emp)

    return result


@mcp.tool()
def list_departments():
    """
    Returns all departments.
    """

    employees = load_employees()

    departments = sorted(
        {emp["department"] for emp in employees}
    )

    return departments


@mcp.tool()
def employees_by_department(department: str):
    """
    List employees in a department.
    """

    employees = load_employees()

    result = [
        emp
        for emp in employees
        if emp["department"].lower() == department.lower()
    ]

    return result


if __name__ == "__main__":
    mcp.run()